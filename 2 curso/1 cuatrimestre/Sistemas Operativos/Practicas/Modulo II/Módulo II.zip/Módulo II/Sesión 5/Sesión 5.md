### SESIÓN 5 - MÓDULO II

____________________

##### <u>Ejercicio 1</u>: Compila y ejecuta los siguientes programas y trata de entender su funcionamiento.

El programa _reciboSignal.c_ modifica la acción que tomará cuando reciba dos señales: _SIGUSR1_ y _SIGUSR2_. Esto lo hacemos con la llamada _sigaction_. El primer parámetro debe ser la señal de la que queremos modificar el comportamiento si es recibida (en este caso como queremos modificar el comportamiento ante dos señales, llamaremos dos veces a la función). El segundo parámetro es un struct definido con detalle en los apuntes. Lo importante es cambiar su variable _sa_handler_, que apunta a lo que queremos que realice el programa al realizar la señal, vaciar la máscara de señales _sa.mask_ que deberían bloquearse durante la ejecución del manejador de la señal, e inicializar _sa.flags_ a 0 o _SA_RESTART_ (no sé cuál es la diferencia, _SA_RESTART_ es para que siga con la ejecución el programa después de la señal).
Como vemos en el código, lo hemos configurado de tal manera que cuando el programa reciba _SIGUSR1_ o _SIGUSR2_, pasará a ejecutar la función _sig_USR_hdlr_, que imprimirá un mensaje a la pantalla según qué señal ha recibido. Nótese que esta función es llamada desde _sigaction_ con un parámetro entero, que es el que describe qué señal se está modificando [si enviamos _SIGUSR1_, se hará la llamada sig_USR_hdlr(SIGUSR1), y sabemos que SIGUSR1 es realmente un entero que describe la señal unívocamente, SIGUSR1 == 10 en este caso].

El segundo programa _envioSignal.c_ sirve para ahora enviar una señal a un proceso, lo cual es sencillo gracias a la llamada _kill_. El primer parámetro es el _PID_ del proceso al que le queremos enviar la señal, y el segundo la señal. Viendo el código, vemos que este programa recibe estos dos mismo parámetros como parámetros suyos (./envioSignal \[012] \<PID>, y según llamamos con 0, 1 o 2, se enviará la señal _SIGTERM, SIGUSR1_ o  _SIGUSR2_, respectivamente). 

La siguiente sesión con doble _shell_ nos confirma que nuestros programas funcionan bien.

```shell
# Primera consola
$ ./reciboSignal

Recibida la senal SIGUSR1

Recibida la senal SIGUSR2

Terminado
```

```shell
# Segunda consola (ejecutando al mismo tiempo)
$ ps -e | grep reciboSignal
30746 pts/0    00:00:03 reciboSignal
$ ./envioSignal 1 30746
$ ./envioSignal 2 30746
$ ./envioSignal 0 30746
```



##### <u>Ejercicio 2</u>: Escribe un programa en C llamado contador, tal que cada vez que reciba una señal que se pueda manejar, muestre por pantalla la señal y el número de veces que se ha recibido ese tipo de señal, y un mensaje inicial indicando las señales que no puede manejar. En el cuadro siguiente se muestra un ejemplo de ejecución del programa.

```c
#include <sys/types.h>
#include <limits.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>

void handler(int signum){
    // Se inicializa una sola vez y guarda valores a través de las llamadas a la función
    static int recuento[_NSIG] = {0};
    recuento[signum-1] += 1;
    printf("Recibida la señal %d, un total de %d veces\n", signum, recuento[signum-1]);
}

int main(){
    struct sigaction sa;
    
    sa.sa_handler = handler;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);

    printf("No puedo manejar las señales 9 (SIGKILL), 19 (SIGSTOP), 32 y 33\n");
    printf("Esperando la recepción de señales...\n");

    // Definimos el comportamiento para todas las señales (kill -l para listarlas) recorriendolas con un for
    for (int i = 1; i < _NSIG; ++i)
        if (sigaction(i, &sa, NULL) == -1)
            printf("Error al intentar establecer el manejador de la señal %d\n", i);

    while (1);
}
```



##### <u>Ejercicio 3</u>:  Escribe un programa que suspenda la ejecución del proceso actual hasta que se reciba la señal SIGUSR1. Consulta en el manual en línea sigemptyset para conocer las distintas operaciones que permiten configurar el conjunto de señales de un proceso
```c
#include <stdio.h>
#include <signal.h>

int main(){
    sigset_t new_mask;

    // Inicializar la nueva mascara de señales a todas las señales
    // {SIGHUP, SIGINT, ..., SIGRTMAX}
    sigfillset(&new_mask); 

    // Eliminamos SIGUSR1 de la máscara de señales a bloquear
    // {SIGHUP, SIGINT, ..., SIGKILL, SIGSEGV, ..., SIGRTMAX}
    sigdelset(&new_mask, SIGUSR1); 

    // Esperar solo a SIGUSR1
    sigsuspend(&new_mask);

    return 0;
}
```



##### <u>Ejercicio 4</u>: Compila y ejecuta los siguientes programas y trata de entender su funcionamiento.

Lo que hace este programa es configuar el manejador de la señal _SIGTERM_. La ejecución dura 11 segundos y según se haya enviado en los primeros 10 segundos la señal _SIGTERM_, terminará el programa imprimiendo el mensaje de "Señal recibida" o no. El creador del programa decide bloquear la señal _SIGTERM_ en estos 10 segundos. Bloquearla significa que el programa aceptará la señal una vez la desbloquee, es decir, si se recibe la señal a los 5 segundos, no se ejecutará la función _handler_ hasta después de otros 5 segundos, cuando se desbloquee.

Duda: ¿conj_mascaras_original no se inicializa?

Duda: Si comento el código para bloquear y desbloquear la señal, el programa parece que se salta el sleep, imprime "Señal recibida" un segundo después de mandarle la señal, sin haber pasado los 10 segundos. | Posible respuesta: SIGTERM mata a sleep.