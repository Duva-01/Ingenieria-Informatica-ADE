//Ejercicio: Frecuencia de calficaciones


#include <iostream>


using namespace std;

int main(){
	int num_alumnos;
	double nota ;
	
	cout << "Introduzca el numero de alumnos. Debe ser al menos uno: " ;
	cin >> num_alumnos;
	
	while(num_alumnos < 1){
		cout << "Error. Debe haber al menos un alumno. Vuelva a introducirlo: " ;
		cin >> num_alumnos ;
	}
	
	
	double contador_suspensos=0;
	double contador_aprobados=0;
	double contador_notables=0;
	double contador_sobresalientes=0;
	
	
	cout << "Introduzca la secuencia de " << num_alumnos << " notas" << endl;
   for(int i = 1; i <= num_alumnos; i++){
   	cout << "Nota: " << i << " : " ;
   	cin >> nota;
   	
   	while ( nota < 0 || nota > 10){
   		cout << "Nota fuera de rango. Vuelva a introducirla: " ;
   		cin >> nota;
   	}
   	
   	if (nota >= 0 && nota < 5){
   		contador_suspensos++;
   	}
   	
   	if (nota >= 5 && nota < 7){
   		contador_aprobados++;
   	}
   	
   	if (nota >= 7 && nota < 9){
   		contador_notables++;
   	}
   	
   	if ( nota >= 9 && nota <= 10){
   		contador_sobresalientes++;
   	}
   }
   
   cout << "Suspensos: " << contador_suspensos << " ( " << (contador_suspensos*10)/num_alumnos << "% )" << endl ;
   cout << "Aprobados: " << contador_aprobados << " ( " << (contador_aprobados*10)/num_alumnos << "% )" << endl ;
   cout << "Notables: " << contador_notables << " ( " << (contador_notables*10)/num_alumnos << "% )" << endl ;
   cout << "Sobresalientes: " << contador_sobresalientes << " ( " << (contador_sobresalientes*10)/num_alumnos << "% )" << endl;
}
   	
