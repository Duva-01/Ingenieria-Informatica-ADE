/**
 * @file pmm-original.c
 * @author Daniel Pérez Ruiz
 * @brief Implementacion de producto de matrices (ORIGINAL)
 *
 * Compilacion: gcc -O2 pmm-original.c -o pmm-original
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

//USO DE VARIABLES GLOBALES:
#define TAM_MAX 1024

double m1[TAM_MAX][TAM_MAX];
double m2[TAM_MAX][TAM_MAX];
double mm[TAM_MAX][TAM_MAX];

#define VAR_DYNAMIC //REALIZA LOS CALCULOS CON VARIABLES DINAMICAS

//FUNCION PRINCIPAL
int main(int argc, char ** argv){
    //VARIABLES PARA EL CALCULO DEL TIEMPO
    struct timespec cgt1,cgt2;
    double ncgt;

    int tam = TAM_MAX;

    //PASO 3: INICIALIZACION DE VECTOR Y MATRIZ
    for(int i=0; i<tam; i++){
        for(int j=0; j<tam; j++){
            m1[i][j] = tam*0.1+i*0.1-j*0.1;
            m2[i][j] = i*0.1+tam;
            mm[i][j] = 0;
        }
    }

    //PASO 4: CALCULO DEL PRODUCTO
    double suma;
    clock_gettime(CLOCK_REALTIME,&cgt1);
    for(int i = 0; i<tam ; i++)
      for(int j = 0; j<tam; j++)
        for(int k = 0; k<tam; k++)
          mm[i][j] += m1[i][k] * m2[k][j];


    clock_gettime(CLOCK_REALTIME,&cgt2);

    //PASO 5: MOSTRAR EL RESULTADO
    printf(">> MOSTRANDO RESULTADOS DE MULTIPLICACION << \n");
    for(int j=0; j<5; j++){
        printf(" --> MM[%d][%d] = %f\n", 0,j,mm[0][j]);
    }
    printf("\n ...../\n");
    for(int j=TAM_MAX-5; j<(TAM_MAX); j++){
        printf(" --> MM[%d][%d] = %f\n", TAM_MAX-1,j, mm[TAM_MAX-1][j]);
    }

    //PASO 6: CALCULO DEL TIEMPO DE EJECUCION
    ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+(double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));
    printf("\n>> TIEMPO DE EJECUCION: %11.9f || DIMENSION: %d \n",ncgt,tam);

    return EXIT_SUCCESS;
}
