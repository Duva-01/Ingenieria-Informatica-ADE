#!/bin/bash

if [[ $# != 1 ]]; then
    echo "Error de argumentos"

else

    for ((N=65536;N<67108865;N=N*2));do
        ./$1 $N
        done

fi


