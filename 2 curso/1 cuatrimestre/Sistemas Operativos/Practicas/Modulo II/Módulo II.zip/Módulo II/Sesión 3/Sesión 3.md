### SESIÓN 3 - MÓDULO II

____

##### <u>Ejercicio 1</u>: Implementa un programa en C que tenga como argumento un número entero. Este programa debe crear un proceso hijo que se encargará de comprobar si dicho número es un número par o impar e informará al usuario con un mensaje que se enviará por la salida estándar. A su vez, el proceso padre comprobará si dicho número es divisible por 4, e informará si lo es o no usando igualmente la salida estándar.

```c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[]){
    int numero;
    pid_t pid;

    // Control de parámetros
    if (argc != 2){
        printf("Error en el número de argumentos\n");
        exit(-1);
    }
    
    numero = atoi(argv[1]);
    pid = fork();
    if (pid == -1){
        printf("Error en la creación de un proceso hijo\n");
        exit(-1);
    }
    
    printf("Mi PID es: %d, y mi PPID es: %d\n", getpid(), getppid());

    // Tareas para el proceso padre
    if (pid != 0){
        printf("\n-> Estas instrucciones solo serán ejecutadas por el padre\n");

        if (numero % 4 == 0)
            printf("\nEl número introducido %d múltiplo de 4\n", numero);
        else
            printf("\nEl número introducido %d no es múltiplo de 4\n", numero);
    }

    // Tareas para el proceso hijo
    if (pid == 0){
        printf("\n-> Estas instrucciones están siendo ejecutadas solo por el hijo\n");

        if (numero % 2 == 0)
            printf("\nEl número introducido %d es par\n", numero);
        else
            printf("\nEl número introducido %d es impar\n", numero);
    }
    
    return EXIT_SUCCESS;
}
```



##### <u>Ejercicio 2</u>: ¿Qué hace el siguiente programa? Intenta entender lo que ocurre con las variables y sobre todo con los mensajes por pantalla cuando el núcleo tiene activado/desactivado el mecanismo de buffering.

Lo primero que hace el siguiente programa es escribir por pantalla dos mensajes, uno con la llamada al sistema _write_ ("Cualquier mensaje de salida"), y otro con _printf_ ("Mensaje previo a la ejecución del _fork_"). Posteriormente se ejecuta un _fork()_ y se ejecutan unas instrucciones con el proceso padre y otras con el hijo. Nuestra sorpresa al ejecutar este programa es que el mensaje que imprimimos con _printf_ se imprime dos veces. El proceso hijo parece que lo imprime. Pero, ¿cómo es posible si la instrucción es previa a su invocación? La respuesta es por cómo funciona _printf_ y el búffer. Al llamar a _printf_ el padre (sin estar el hijo creado), el mensaje se almacena en búffer y no se imprime al momento. Se siguen ejecutando instrucciones y cuando se crea el hijo, este hereda el PCB y con él, el búffer del padre. Así, cuando el hijo finalmente libera el búffer e imprime por pantalla, imprime el mensaje anterior.

Si desactivamos que haya búffer, que se hace con la llamada al sistema _setvbuf_, entonces esto ya no ocurre. Es por ello también, que como write no imprime con este mecanismo de búffer, desde el principio el mensaje que con él imprimiamos, no se imprimía dos veces si no una.



##### <u>Ejercicio 3</u>: Indica qué tipo de jerarquías de procesos se generan mediante la ejecución de cada uno de los siguientes fragmentos de código. Comprueba tu solución implementando un código para generar 20 procesos en cada caso, en donde cada proceso imprima su PID y el del padre, PPID.

Exisen dos tipos de jerarquías de procesos. En la primera el padre crea un hijo, y este hijo crea a su vez otro hijo, y así sucesivamente. En la segunda,  el padre va creando hijos. En el siguiente código vemos una implementación práctica de ambas jerarquías.

```c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int iteracion = 0;

int main(){
    int childpid, nprocs = 20;

    printf("Jerarquía de procesos 1\n");
    printf("-----------------------\n");

    for (int i = 0; i < nprocs; ++i){
        iteracion += 1;
        if ((childpid = fork()) == -1){
            printf("Error en la creación de un proceso hijo: %s\n", strerror(errno));
            perror("Error en fork\n");
            exit(EXIT_FAILURE);
        }

        // El padre se va "destruyendo" y el hijo continua en el búcle creando hijos. 
        if (childpid != 0){
            printf("Mi PID es: %d, y mi PPID es: %d. Iteración %d\n", getpid(), getppid(), iteracion);
            break;
        }
    }

    // printf("\n\nJerarquía de procesos 2\n");
    // printf("-----------------------\n");

    // for (int i = 0; i < nprocs; ++i){
    //     iteracion += 1;
    //     if ((childpid = fork()) == -1){
    //         printf("Error en la creación de un proceso hijo: %s\n", strerror(errno));
    //         perror("Error en fork\n");
    //         exit(EXIT_FAILURE);
    //     }

    //     // El hijo se va "destruyendo" y el padre original continua en el búcle creando hijos. 
    //     if (childpid == 0){
    //         printf("Mi PID es: %d, y mi PPID es: %d. Iteración %d\n", getpid(), getppid(), iteracion);
    //         break;
    //     }
    // } 

    sleep(1);
    return EXIT_SUCCESS;
}
```



##### <u>Ejercicio 4</u>: Implementa un programa que lance cinco procesos hijo. Cada uno de ellos se identificará en la salida estándar, mostrando un mensaje del tipo Soy el hijo PID. El proceso padre simplemente tendrá que esperar la finalización de todos sus hijos y cada vez que detecte la finalización de uno de sus hijos escribirá en la salida estándar un mensaje:

```c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main(){
    int parentpid = getpid();

    // Quitamos el búffer
    setvbuf(stdout, NULL, _IONBF, 0);

    // Creación de 5 hijos por el proceso padre original
    for (int i = 0; i < 5 && getpid() == parentpid; ++i){
        int pid = fork();

        if (pid == 0)
            printf("Soy el hijo %d\n", getpid());
    }

    // Terminación de los cinco hijos
    for (int i = 0; i < 5 && getpid() == parentpid; ++i){
        int childpid = wait(0);

        printf("\nAcaba de terminar mi hijo %d", childpid);
        printf("\nMe quedan %d hijos vivos\n", 4-i);
    }

    return EXIT_SUCCESS;
}
```



##### <u>Ejercicio 5:</u> Implementa una modificación sobre el anterior programa en la que el proceso padre espera primero a los hijos creados en orden impar (1º, 3º, 5º) y después a los hijos pares (2º y 4º).

```c
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>

#define NUMHIJOS 5

int main(int argc, char *argv[]){
	int estado;
	int i, j, k;
	int buffer[NUMHIJOS];
	pid_t pid;
    
	if (setvbuf(stdout, NULL, _IONBF, 0) != 0){
		perror("\nError en setvbuf");
	}

	for (i = 0; i < NUMHIJOS; i++){
		if ((pid = fork()) < 0){
			perror("\nError en el fork");
			exit(-1);
		}

		if (pid == 0) break;
		buffer[i] = pid;
	}
    
	// Proceso hijo
	if (pid == 0){ 
		printf("\nSoy el hijo %d\n", getpid());
		exit(0);
	}

	// Proceso padre
	sleep(1);
	if (pid != 0){
		// Con k = 1 esperamos a los impares y después con k = 2 a los pares
		for(j = k = 1; j <= 2; ++j){
			for(; k <= NUMHIJOS; k += 2){
				pid_t childpid;

				// Con waitpid podemos especificar a qué proceso esperar
				// pid = waitpid(buffer[k], NULL, NULL);
				childpid = waitpid(buffer[k-1], &estado, NULL);

				printf("\nAcaba de finalizar mi hijo con PID %d y con estado %d\n", childpid, estado);
				printf("Sólo me quedan %d hijos vivos\n", i);
				i--;
			}
			k = 2;
		}
	}
	printf("\n");

	return 0;
}
```



##### <u>Ejercicio 6</u>: ¿Qué hace el siguiente programa?

El siguiente programa lo único que hace crear un hijo y le manda ejecutar otro programa, en este caso, _ldd_. El padre espera a que termine e imprime el estado con el que el hijo ha finalizado, es decir, el valor de retorno al finalizar el programa.  



##### <u>Ejercicio 7:</u> Escribe un programa que acepte como argumentos el nombre de un programa, sus argumentos si los tiene, y opcionalmente la cadena “bg”. Nuesto programa deberá ejecutar el programa pasado como primer argumento en foreground si no se especifica la cadena “bg” y en background en caso contrario. Si el programa tiene argumentos hay que ejecutarlo con éstos.	

```c
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char* argv[]){
    bool background = false; 
    char bg[] = "bg";
    char* argumentos[argc];
    int contador = 0, nargs = argc;

    if (argc == 1){
        printf("Sintaxis de ejecución: ./ejercicio7 <programa> <arg1> <arg2> ...\n");
        exit(1);
    }

    // Procesamiento de los argumentos
    for (int i = 1; i < argc; ++i){
        if (strcmp(bg, argv[i]) == 0){
            background = true;
            nargs -= 1;
        }
        else{
            argumentos[contador] = (char*)malloc(sizeof(argv[i]) * sizeof(char));
            strcpy(argumentos[contador], argv[i]);
            contador += 1;
        }
    }
    argumentos[nargs-1] = NULL;

    if (background){
        // Creamos un proceso hijo que ejecute el programa
        pid_t childpid = fork();
        if (childpid == 0)
            if (execvp(argumentos[0], argumentos) == -1){
                printf("Error en la ejecución del programa.\n");
                exit(EXIT_FAILURE);
            }
    }
    else{
        if (execvp(argumentos[0], argumentos) == -1){
            printf("Error en la ejecución del programa.\n");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < nargs-1; ++i)
        free(argumentos[i]);

    return EXIT_SUCCESS;
}
```

