### SESIÓN 1 - MÓDULO II

____

##### <u>Ejercicio 1</u>: ¿Qué hace el siguiente programa? Probad tras la ejecución del programa las siguientes órdenes del shell: $> cat archivo y $> od -c archivo. (Respuesta copiada del Portfolio Jesús García)

- Lo que hace el siguiente programa es crear dos arrays: buf1 y buf2 que contienen 10 caracteres cada uno. Crea un entero fd al cual asigna el valor de la llamada al sistema open del archivo “archivo”, el resultado del cual da error si es menor que cero. Con **O_CREAT** se crea si no existe, con **O_TRUNC** si existe el fichero y tiene habilitada la escritura, lo sobreescribe a tamaño 0, con **O_WRONLY** decimos que solo se permite escritura, con **S_IRUSR** comprobamos que el usuario tiene permiso de lectura, por último con **S_IWUSR** comprobamos que el usuario tiene permiso de escritura.

- Después comprueba que si, después de hacer la orden write del primer búfer, el resultado asociado a esta operación es distinto de 10 se muestra error, dado que hemos escrito los 10 caracteres del primer búfer en el archivo.

- Después con lseek ponemos el puntero del archivo en la posición 40 (en bytes) desde **SEEK_SET** (inicio del fichero), y da error si el resultado de la operación es menor que 0.

- Por último llamamos a write para el segundo búfer igual que hemos hecho antes con el primero. Esto imprime los 10 caracteres de buf2. Hacemos el cat del archivo y vemos que está bien impreso, y con _od_ examinamos cada bit:

  ```shell
  $ cat archivo
  abcdefghijABCDEFGHIJ
  
  $ od -c archivo
  0000000   a   b   c   d   e   f   g   h   i   j  \0  \0  \0  \0  \0  \0
  0000020  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0  \0
  0000040  \0  \0  \0  \0  \0  \0  \0  \0   A   B   C   D   E   F   G   H
  0000060   I   J
  0000062
  ```

  

##### <u>Ejercicio 2</u>: Implementa un programa que acepte como argumento un ''pathname'', abra el archivo correspondiente y utilizando un tamaño de partición de los bytes del archivo igual a 80 Bytes cree un archivo de salida en el que debe aparecer lo siguiente: [...]. Si no se pasa un argumento al programa se debe utilizar la entrada estándar como archivo de entrada.

```c
// Biblioteca para printf()
#include <stdio.h>
// Bibliotecas para trabajar con open()
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
// Biblioteca para trabajar con read() y con write(), y con las variables de I/O estándares
#include <unistd.h>
// Biblioteca para trabajar con la variable para manejar errores errno
#include <errno.h>
// Biblioteca para utilizar strlen()
#include <string.h>
// Biblioteca para poder utilizar exit()
#include <stdlib.h>

int main(int argc, char *argv[]){
	int filein, fileout;
	int cont = 0, leidos;
    char string[] = "El número de bloques es %d\n";
	char buff_1[80], buff_2[30];

	// int open(const char *pathname, int flags);
	// Required flags: O_RDONLY, O_WRONLY, or O_RDWR
	if (argc == 2){
        // Abrimos el archivo de entrada con permisos de solo lectura
		if ( (filein = open(argv[1], O_RDONLY)) < 0){
            printf("Error %d en apertura del fichero de entrada\n", errno);
            perror("Error en open\n");
            exit(-1);
        }
	}
	else if (argc == 1){
        // Nuestra variable para la entrada de datos estará asociada a la entrada estándar
		filein = STDIN_FILENO;
	}
    else{
        printf("Error en el número de argumentos\n");
        printf("Terminando programa...\n");
        exit(-1);
    }
    
    // Abrimos/Creamos el archivo de salida
	// O_TRUNC: If the file already exists and is a regular file and the open mode allows writing it will be truncated to length 0.
	// O_WRONLY: Request opening the file write-only
	// S_IRUSR: 00400 user has read permission 
	// S_IWUSR: 00200 user has write permission 
	if ( (fileout = open("salida.txt", O_CREAT|O_TRUNC|O_WRONLY, S_IRUSR|S_IWUSR)) < 0){
        printf("Error %d en apertura del fichero de salida\n", errno);
        perror("Error en open\n");
        exit(-1);
    }
    
    // Empezamos unos bytes más adelante para reservar espacio para imprimir después el mensaje del apartado 2
    lseek(fileout, strlen(string), SEEK_SET);

    // Vamos leyendo de 80 en 80 los caracteres desde la entrada, almacenado en buff1
    // ssize_t read(int fd, void *buf, size_t count);
    while( (leidos = read(filein, buff_1, 80)) != 0){
        if (leidos == -1){
            printf("Error %d en la lectura del fichero de entrada\n", errno);
            perror("Error en read");
            exit(-1);
        }

		// Utilizamos sprintf para almacenar en buff_out nuestro mensaje informativo
		cont++;
		sprintf(buff_2, "\nBloque %d\n", cont);
		write (fileout, buff_2, strlen(buff_2));
		write (fileout, buff_1, leidos);
		write (fileout, "\n", 1);
	}
    
    // Segunda parte del ejercicio. Poner al principio el mensaje del número de bloques
    lseek(fileout, 0, SEEK_SET);
    sprintf(buff_2, string, cont);
    write(fileout, buff_2, strlen(buff_2));
    
    // Finalizamos el programa cerrando antes los ficheros abiertos
    if (close(fileout) == -1){
        printf("Error %d al cerrar el fichero de salida\n", errno);
        perror("Error en close\n");
        exit(-1);
    }

    if(close(filein) == -1){
        printf("Error %d al cerrar el fichero de entrada\n", errno);
        perror("Error en close\n");
        exit(-1);
    }
	
	return EXIT_SUCCESS;
}
```



##### <u>Ejercicio 3</u>: ¿Qué hace el siguiente programa?  (Respuesta copiada del Portfolio Jesús García)

- Una vez que hemos compilado el ejercicio y lo hemos ejecutado pasándole como argumento <nombre_archivo> , lo que hace es decirnos que tipo de archivo es, ya sea un archivo regular, un directorio, un dispositivo de bloques, etc...
- Internamente, el programa comprueba cada flag correspondiente a un archivo determinado con el archivo que hemos introducido como parámetro, y si se activa nos mostrará el tipo de archivo en el cual se ha activado.



##### <u>Ejercicio 4</u>: Define una macro en lenguaje C que implemente la macro S_ISREG(mode) usando para ello los flags definidos en <sys/stat.h> para el campo st_mode de la struct stat. y comprueba que funciona en un programa simple.
```c
#define S_ISREG2(mode) ((mode & S_IFMT) == S_IFREG))
```

