#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char const *argv[])
{
    
    if(argc != 2){
        printf("Error de argumentos %s N(tam matriz cuadrada)", argv[0]);
        return(EXIT_FAILURE);
    }

    const int N = atoi(argv[1]);

    #ifdef GLOBAL
        int matriz[N][N];
        int vector[N];
        int vector_resultado[N];

        for(int i = 0; i < N; ++i){
            vector[i] = i;
            for(int j = 0; j < N; ++j){
                matriz[i][j] = j;
            }
        }

        printf("Ejecutado GLOBALMENTE\n");
    #endif

    #ifdef DINAMICO
        int **matriz = new int*[N];
        for(int i = 0; i < N; ++i){
            matriz[i] = new int[N];
        }
        int *vector = new int[N];
        int *vector_resultado = new int[N];

        for(int i = 0; i < N; ++i){
            vector[i] = i;
            for(int j = 0; j < N; ++j){
                matriz[i][j] = j;
            }
        }

        printf("Ejecutado DINAMICAMENTE\n");
    #endif

    //Calculo de producto

    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            
        }
        
    }
    
        
    

    



    return 0;
}
