#!/bin/bash
#Nombre: getTimes.sh
#Autor: Daniel Pérez Ruiz
#Descripción: Calcula los tiempos de ejecución para una serie de tamaños del programa daxpy
#Uso: ./getTimes.sh "bin_file"

#1. OBTENCION DE NOMBRES
EXT=".txt"
TIEMPOS="TIEMPOS_"

BIN="$1"
OUT_FILE="$TIEMPOS$BIN$EXT"

#2. EJECUCION DE PROGRAMA
MIN=32768
MAX=33554432

for (( i=$MIN ; i<=$MAX ; i*=2 )) do
	echo "EJECUCION DE [$BIN] PARA DIMENSION [$i <= $MAX]"
	./$1 >> $OUT_FILE
done
