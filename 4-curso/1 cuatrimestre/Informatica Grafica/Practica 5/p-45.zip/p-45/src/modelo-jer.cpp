// Nombre: David Apellidos: Martinez Diaz Titulación: GIADE.
// email: dmartinez01@correo.ugr.es DNI o pasaporte: 44669141J

#include "ig-aux.h"
#include "malla-ind.h"   // declaración de 'ContextoVis'
#include "lector-ply.h"
#include "modelo-jer.h"
#include "malla-revol.h"

using namespace std;

C::C(const float velocidad){

   int indice = agregar(MAT_Rotacion((45.0 + velocidad), {1.0, 0.0, 0.0}));
   agregar( MAT_Traslacion( {0.1,1.0,0.0} ) );// Tra[0.1, 0.1]
   agregar( MAT_Escalado( 0.4,0.8,1.0 ) ); // Esc[0.4, 0.8]

   agregar( new MallaPiramideL() ); 

   rotacion = leerPtrMatriz(indice);
   

}
// Redefinimos metodo leerNumParametros()

unsigned C::leerNumParametros() const{
    
   return 1;
}

// Redefinimos metodo actualizarEstadoParametro()
void C::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         *rotacion = MAT_Rotacion((45.0 + tSec), {1.0, 0.0, 0.0});
      break;
   
   default:
         *rotacion = MAT_Rotacion((45.0 + tSec), {1.0, 0.0, 0.0});
      break;
   }

}

// --------------------------------------------

// Proyecto Helicoptero
CuboProyectoUbicado::CuboProyectoUbicado(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z, float a, float b, float c){

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   agregar(new Cubo24(a, b, c));
}

NodoCesped::NodoCesped(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z, float a, float b, float c){

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   Textura * C01 = new TexturaXYZ("cesped.jpg");
   agregar(new Material(C01, 0.5, 0.5, 12, 400));

   agregar(new Cubo24());
}

NodoTroncoArbol::NodoTroncoArbol(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z, float a, float b, float c){

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   Textura * T02 = new Textura("text-madera.jpg");
   agregar(new Material(T02, 0.8, 0.8, 12, 140));

   agregar(new Cubo24());
}

NodoMeteorito::NodoMeteorito(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z, float a, float b, float c){

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   Textura * M03 = new Textura("fuego.jpg");
   agregar(new Material(M03, 1, 1, 12, 60));

   agregar( new Esfera(30, 15));
}

//----------------------------------------

HeliceHelicopteroLateral::HeliceHelicopteroLateral(){

   ponerIdentificador(0);
   agregar(MAT_Traslacion({-3.0,0.0,-0.6}));

   int indice = agregar(MAT_Rotacion((0.0), {1.0, 0.0, 0.0}));
 
   agregar( new CuboProyectoUbicado(0.0, 0.0, 0.0, 0, 1.0, 0.0, 0.0, 0.05, 0.4, 0.05, 0.35, 0.35, 0.35) ); 

   rotacionHeliceLateral = leerPtrMatriz(indice);

}

unsigned HeliceHelicopteroLateral::leerNumParametros() const{
    
   return 2;
}

// Redefinimos metodo actualizarEstadoParametro()
void HeliceHelicopteroLateral::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{  
   cout << "iParam: " << iParam << "  leerNumParametros(): " << leerNumParametros() << endl  ;
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 1:
         *rotacionHeliceLateral = MAT_Rotacion((360*2.5 * tSec), {0.0, 0.0, 1.0});
      break;
   
   }

}

//---------------------------------------

HeliceHelicopteroArriba::HeliceHelicopteroArriba(){

   ponerIdentificador(0);
   int indice = agregar(MAT_Rotacion((0.0), {1.0, 0.0, 0.0}));

   agregar( new CuboProyectoUbicado(0.0, 0.7, 0.0, 0, 1.0, 0.0, 0.0, 1.5, 0.1, 0.1, 0.35, 0.35, 0.35) ); 

   rotacionHeliceArriba = leerPtrMatriz(indice);
}

unsigned HeliceHelicopteroArriba::leerNumParametros() const{
    
   return 1;
}

// Redefinimos metodo actualizarEstadoParametro()
void HeliceHelicopteroArriba::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         *rotacionHeliceArriba = MAT_Rotacion((360*2.5 * tSec), {0.0, 1.0, 0.0});
      break;
   
   }

}

//------------------------------------------

TroncoHelicoptero::TroncoHelicoptero(){

   ponerIdentificador(23);
   agregar( new CuboProyectoUbicado(0.0, 0.0, 0.0, 0, 1.0, 0.0, 0.0, 1.0, 0.5, 0.5, 1.0, 0.1, 0.1) ); // Tronco Principal

   agregar( new CuboProyectoUbicado(0.5, 0.0, 0.0, 0, 1.0, 0.0, 0.0, 0.25, 0.35, 0.60, 0.0, 0.0, 0.80) ); // Ventanas
   agregar( new CuboProyectoUbicado(0.90, 0.0, 0.0, 0, 1.0, 0.0, 0.0, 0.20, 0.35, 0.40, 0.0, 0.0, 0.80) ); // Ventanas
   
   agregar( new CuboProyectoUbicado(0.0, 0.5, 0.0, 0, 1.0, 0.0, 0.0, 0.1, 0.2, 0.1, 0.35, 0.35, 0.35) ); // Pivote arriba
}

//------------------------------------

ParteAbajoHelicoptero::ParteAbajoHelicoptero(){
   
   ponerIdentificador(0);
   agregar( new CuboProyectoUbicado(0.0, -0.5, 0.25, 0, 1.0, 0.0, 0.0, 0.1, 0.2, 0.1, 0.35, 0.35, 0.35) ); // Pivote abajo
   agregar( new CuboProyectoUbicado(0.0, -0.5, -0.25, 0, 1.0, 0.0, 0.0, 0.1, 0.2, 0.1, 0.35, 0.35, 0.35) ); // Pivote abajo

   agregar( new CuboProyectoUbicado(0.0, -0.75, 0.25, 0, 1.0, 0.0, 0.0, 0.85, 0.1, 0.2, 0.35, 0.35, 0.35) ); // Aletas
   agregar( new CuboProyectoUbicado(0.0, -0.75, -0.25, 0, 1.0, 0.0, 0.0, 0.85, 0.1, 0.2, 0.35, 0.35, 0.35) );  // Aletas

}

//---------------------------------------

ColaHelicoptero::ColaHelicoptero(){

   ponerIdentificador(0);
   agregar( new CuboProyectoUbicado(-2.0, 0.0, 0.0, 0, 1.0, 0.0, 0.0, 1.0, 0.25, 0.25, 1.0, 0.1, 0.1) ); 
   agregar( new CuboProyectoUbicado(-3.0, 0.0, 0.0, 0, 1.0, 0.0, 0.0, 0.4, 0.4, 0.4, 1.0, 0.1, 0.1) ); 

   agregar( new CuboProyectoUbicado(-3.0, 0.0, -0.2, 0, 1.0, 0.0, 0.0, 0.1, 0.1, 0.4, 0.35, 0.35, 0.35) ); 
}

//-----------------------------------------

Escenario::Escenario(){

   ponerIdentificador(0);
   
   // Bloque de cesped

   NodoCesped * cesped = new NodoCesped(0.0, -3.0, 0.0, 0, 1.0, 0.0, 0.0, 20.0, 1.0, 20.0, 0.1, 1.0, 0.1);
   cesped->ponerIdentificador(1);
   agregar( cesped ); 

   
   // Arboles

   NodoTroncoArbol * tronco1 = new NodoTroncoArbol(5.0, -1.0, 7.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas1 = new CuboProyectoUbicado(5.0, 0.0, 7.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1);
   tronco1->ponerIdentificador(2);
   ramas1->ponerIdentificador(3);

   agregar(tronco1); 
   agregar(ramas1); 

   //----------------------------------------

   NodoTroncoArbol * tronco2 = new NodoTroncoArbol(-10.0, -1.0, 7.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas2 = new CuboProyectoUbicado(-10.0, 0.0, 7.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1);

   tronco2->ponerIdentificador(4);
   ramas2->ponerIdentificador(5);

   agregar(tronco2); 
   agregar(ramas2); 

   //---------------------------------------

   NodoTroncoArbol * tronco3 = new NodoTroncoArbol(-14.0, -1.0, -7.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas3 = new CuboProyectoUbicado(-14.0, 0.0, -7.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1) ;

   tronco3->ponerIdentificador(6);
   ramas3->ponerIdentificador(7);

   agregar(tronco3); 
   agregar(ramas3); 

   //---------------------------------------

   NodoTroncoArbol * tronco4 = new NodoTroncoArbol(17.0, -1.0, 12.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas4 =new CuboProyectoUbicado(17.0, 0.0, 12.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1) ;

   tronco4->ponerIdentificador(8);
   ramas4->ponerIdentificador(9);

   agregar(tronco4); 
   agregar(ramas4); 

   //---------------------------------------

   NodoTroncoArbol * tronco5 = new NodoTroncoArbol(17.0, -1.0, -12.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas5 = new CuboProyectoUbicado(17.0, 0.0, -12.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1) ;

   tronco5->ponerIdentificador(10);
   ramas5->ponerIdentificador(11);

   agregar(tronco5); 
   agregar(ramas5); 

   //---------------------------------------

   NodoTroncoArbol * tronco6 = new NodoTroncoArbol(9.0, -1.0, -4.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas6 = new CuboProyectoUbicado(9.0, 0.0, -4.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1);

   tronco6->ponerIdentificador(12);
   ramas6->ponerIdentificador(13);

   agregar(tronco6); 
   agregar(ramas6); 


   //---------------------------------------

   NodoTroncoArbol * tronco7 = new NodoTroncoArbol(-9.0, -1.0, -2.0, 0, 1.0, 0.0, 0.0, 0.5, 1.0, 0.5, 1.0, 0.3, 0.4);
   CuboProyectoUbicado * ramas7 = new CuboProyectoUbicado(-9.0, 0.0, -2.0, 0, 1.0, 0.0, 0.0, 0.75, 0.5, 0.75, 0.1, 0.5, 0.1);

   tronco7->ponerIdentificador(14);
   ramas7->ponerIdentificador(15);

   agregar(tronco7); 
   agregar(ramas7); 

   // Meteorito

   NodoMeteorito * meteorito = new NodoMeteorito(10, 6, 0, 0, 1.0, 0.0, 0.0, 1.0,1.0,1.0, 0, 0, 0);
   meteorito->ponerIdentificador(16);

   agregar(meteorito);
}

//------------------------------------------

FuegoProyecto::FuegoProyecto(){

   ponerIdentificador(0);

   CuboProyectoUbicado * fuegoGrande =  new CuboProyectoUbicado(0.0, -2.0, 0.0, 0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.7, 0.0, 0.0);
   fuegoGrande->ponerIdentificador(17);
   
   agregar(fuegoGrande);

   int indice = agregar(MAT_Traslacion({1, 1, 1}));
   
   //--------------------------------------

   CuboProyectoUbicado * fuegoPequenio1 =  new CuboProyectoUbicado(0.0, -1.2, 0.0, 0, 1.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0.8, 0.0, 0.0);
   fuegoPequenio1->ponerIdentificador(18);
   agregar(fuegoPequenio1);

   //--------------------------------------

   CuboProyectoUbicado * fuegoPequenio2 =  new CuboProyectoUbicado(0.6, -0.7, 0.6, 0, 1.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0.6, 0.0, 0.0);
   fuegoPequenio2->ponerIdentificador(19);
   agregar(fuegoPequenio2);

   //--------------------------------------

   CuboProyectoUbicado * fuegoPequenio3 =  new CuboProyectoUbicado(0.6, -0.4, -0.6, 0, 1.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0.6, 0.0, 0.0);
   fuegoPequenio3->ponerIdentificador(20);
   agregar(fuegoPequenio3);

   //--------------------------------------

   CuboProyectoUbicado * fuegoPequenio4 =  new CuboProyectoUbicado(-0.6, -0.2, 0.6, 0, 1.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0.6, 0.0, 0.0);
   fuegoPequenio4->ponerIdentificador(21);
   agregar(fuegoPequenio4);

   //--------------------------------------

   CuboProyectoUbicado * fuegoPequenio5 =  new CuboProyectoUbicado(-0.6, -1.0, -0.6, 0, 1.0, 0.0, 0.0, 0.2, 0.2, 0.2, 0.4, 0.0, 0.0);
   fuegoPequenio5->ponerIdentificador(22);
   agregar(fuegoPequenio5);

   traslacionFuego = leerPtrMatriz(indice);
}

unsigned FuegoProyecto::leerNumParametros() const{
    
   return 5;
}

// Redefinimos metodo actualizarEstadoParametro()
void FuegoProyecto::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   cout << "iParam: " << iParam << "  leerNumParametros(): " << leerNumParametros() << endl  ;
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 2:
         *traslacionFuego = MAT_Traslacion({0,sin(tSec),0});  
         
      break;
   
   }

}

//------------------------------------------

Helicoptero::Helicoptero(){

   ponerIdentificador(0);

   agregar (new Escenario() );

   fuego = new FuegoProyecto();
   agregar(fuego);

   int indice = agregar(MAT_Rotacion((0), {1.0, 0.0, 0.0}));
   int indice_2 = agregar(MAT_Traslacion({0,0,0}));
   
   agregar(MAT_Traslacion({0, 2, 3}));    
   agregar( new TroncoHelicoptero() ); 
   agregar( new ParteAbajoHelicoptero() );
   agregar( new ColaHelicoptero() );

   helice_arriba = new HeliceHelicopteroArriba();
   helice_lateral = new HeliceHelicopteroLateral();

   agregar(helice_lateral);
   agregar( helice_arriba );

   rotacion = leerPtrMatriz(indice);
   traslacion = leerPtrMatriz(indice_2);

}

// Redefinimos metodo leerNumParametros()

unsigned Helicoptero::leerNumParametros() const{
    
   return 5;
}

// Redefinimos metodo actualizarEstadoParametro()
void Helicoptero::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   
   
   cout << "iParam: " << iParam << "  leerNumParametros(): " << leerNumParametros() << endl  ;
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
      case 0:

         helice_arriba->actualizarEstadoParametro(iParam, tSec);
      break;

      case 1:
         helice_lateral->actualizarEstadoParametro(1, tSec);
      break;

      case 2:
         fuego->actualizarEstadoParametro(2, tSec);
      break;

      case 3:
         *rotacion = MAT_Rotacion((20 * tSec), {0.0, 1.0, 0.0});
      break;      

      case 4:
         *traslacion = MAT_Traslacion({0,sin(tSec),0});   
      break;
   
   }

}








