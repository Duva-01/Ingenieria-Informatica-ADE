#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>  // Biblioteca para utilizar el struct DIR y dirent
#include <dirent.h>     // Biblioteca con funciones para manejar directorios
#include <ftw.h>        // Biblioteca para trabajar con nftw() 

int regulares = 0;
long long tamano = 0;

int visitar(const char* path, const struct stat* atributos, int flags, struct FTW* ftw){
    if (S_ISREG(atributos->st_mode) && (atributos->st_mode & S_IXGRP) && (atributos->st_mode & S_IXOTH)){
        printf("%s %ld\n", path, atributos->st_ino);

        regulares += 1;
        tamano += atributos->st_size;
    }
    
    return 0;
}

int main(int argc, char *argv[]){
    char pathname[256];

    if (argc > 2){
        printf("Sintaxis: ./ejercicio3 pathname");
        exit(1);
    }
    else if (argc == 2) 
        strcpy(pathname, argv[1]);
    else 
        strcpy(pathname, ".");

    printf("Los i-nodos son:\n");
    nftw(pathname, visitar, 10, 0);
    printf("Existen %d archivos regulares con permiso x para grupo y otros\n", regulares);
    printf("El tamano total ocupado por dichos archivos es %lld bytes\n", tamano);

    return 0; 
}