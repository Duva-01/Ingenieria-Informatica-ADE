#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main(){
    int parentpid = getpid();

    // Quitamos el búffer
    setvbuf(stdout, NULL, _IONBF, 0);

    // Creación de 5 hijos por el proceso padre original
    for (int i = 0; i < 5 && getpid() == parentpid; ++i){
        int pid = fork();

        if (pid == 0)
            printf("Soy el hijo %d\n", getpid());
    }

    // Terminación de los cinco hijos
    sleep(1);
    for (int i = 0; i < 5 && getpid() == parentpid; ++i){
        int childpid = wait(0);

        printf("\nAcaba de terminar mi hijo %d", childpid);
        printf("\nMe quedan %d hijos vivos\n", 4-i);
    }

    return EXIT_SUCCESS;
}