#!/bin/bash

for (( i = 16384; i <= 67108864 ; i*=2 )); do
    time /home/D1estudiante20/bp1/ejer11/SumaVectoresC_parallel_for $i
done
