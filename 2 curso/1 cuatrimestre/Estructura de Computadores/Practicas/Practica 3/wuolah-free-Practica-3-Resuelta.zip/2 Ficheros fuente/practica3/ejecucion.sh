#!/bin/bash

#TEST
echo "TEST"
for i in 0 g 1 2; do
		printf "__OPTIM%1c__%48s\n" $i "" | tr " " "="
	for j in $(seq 1 4); do
		printf "__TEST%02d__%48s\n" $j "" | tr " " "-"
		rm popcount
		gcc popcount.c -o popcount -O$i -D TEST=$j -g
		./popcount
	done
done


echo "-------------------------------------------------------------------------------"

#CRONOS
echo "CRONOS"
for i in 0 g 1 2; do
		printf "__OPTIM%1c__%48s\n" $i "" | tr " " "="
		rm popcount
		gcc popcount.c -o popcount -O$i -D TEST=0
	for j in $(seq 0 10); do
		echo $j; ./popcount
	done | pr -11 -l 22 -w 80
done


#watch -dc -n .1 ./popcount
