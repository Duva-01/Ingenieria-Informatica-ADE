### SESIÓN 4 - MÓDULO II

_________________

##### <u>Ejercicio 1</u>: Pruebe a ejecutar el siguiente código correspondiente a dos programas que modelan el problema del productor/consumidor, los cuales utilizan como mecanismo de comunicación un cauce FIFO. Determine en qué orden y manera se han de ejecutar los dos programas para su correcto funcionamiento y cómo queda reflejado en el sistema que estamos utilizando un cauce FIFO.

Para que funcione bien el funcionamiento de productor/consumidor, tenemos que ejectuar el programa consumidor primero, ya que es el que crea el archivo FIFO. Después ejecutamos el productor y podemos ver como el consumidor imprimirá por pantalla en mensaje que le hemos pasado al productor. Queda reflejado en el sistema que estamos utilizando un cauce FIFO ya que el archivo queda en nuestro sistema de archivos, y si lo inspeccionamos con _ls -l_ vemos que es tipo _p_, que se asocia con los cauces con nombre.

##### <u>Ejercicio 2</u>: Consulte en el manual en línea la llamada al sistema pipe para la creación de cauces sin nombre. Pruebe a ejecutar el siguiente programa que utiliza un cauce sin nombre y describa la función que realiza. Justifique la respuesta.

El siguiente programa pone en práctica cómo crear en C un cauce sin nombre para que ciertos procesos puedan realizarse. Primero, creamos el cauce sin nombre con la llamada al sistema _pipe_, almacenando los descriptores de archivos en el vector _fd_. Después, creamos un proceso hijo con _fork_. Como queremos entablar una comunicación hijo -> padre, el hijo debe cerrar su descriptor de lectura (fd[0]) y el padre el de escritura (fd[1]).  Así, el hijo procede a escribir en el cauce un mensaje, que el padre termina leyendo y mostrando por pantalla.



##### <u>Ejercicio 3</u>:  Redirigiendo las entradas y salidas estándares de los procesos a los cauces podemos escribir un programa en lenguaje C que permita comunicar órdenes existentes sin necesidad de reprogramarlas, tal como hace el shell (por ejemplo ls | sort). En particular, ejecute el siguiente programa que ilustra la comunicación entre proceso padre e hijo a través de un cauce sin nombre redirigiendo la entrada estándar y la salida estándar del padre y el hijo respectivamente.

Este programa emula qué ocurre cuando en la consola ejecutamos la orden _ls | sort_. Como antes, creamos el cauce sin nombre y el proceso hijo. Establecemos la comunicación hijo -> padre. Ahora además, vamos a cambiar la salida estándar del hijo y la entrada estándar del padre. Cerramos la salida estándar del hijo, y a continuación con _dup_ duplicamos el descriptor de escritura al cauce en el descriptor de la salida estándar. Similar con el padre, hacemos que la entrada estándar entre por el descriptor de lectura del cauce. Con _execlp_ ejecutamos _ls_ y _sort_. 

Nota: Salida ~ Escribir ~ Productor | Entrada ~ Lectura ~ Consumidor



##### <u>Ejercicio 4</u>: Compare el siguiente programa con el anterior y ejecútelo. Describa la principal diferencia, si existe, tanto en su código como en el resultado de la ejecución.
Este ejercicio es prácticamente similar al anterior. En lo único que cambia es en las órdenes que utiliza para cambiar la salida estándar y la entrada estándar del hijo y del padre, respectivamente. Además de ahorrarnos una llama al sistema, haciendo _dup2_ el trabajo de las órdenes _stop_ y _dup_, esta orden garantiza que estas dos operaciones se hacen de manera automática, esto es, sin problemas de condiciones de carreras, concurrencia...



##### <u>Ejercicio 5:</u> Este ejercicio se basa en la idea de utilizar varios procesos para realizar partes de una computación en paralelo. Para ello, deberá construir un programa que siga el esquema de computación maestro-esclavo, en el cual existen varios procesos trabajadores (esclavos) idénticos y un único proceso que reparte trabajo y reúne resultados (maestro). Cada esclavo es capaz de realizar una computación que le asigne el maestro y enviar a este último los resultados para que sean mostrados en pantalla por el maestro.

```c
/**
 * @file ejercicio5-maestro.c
 */

#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main(int argc, char* argv[]){
    int fd[2], primo;
    pid_t esclavo_1, esclavo_2;
    char mid_c[20], mid1_c[20];

    // Procesamiento de los argumentos
    if (argc != 3){
        printf("Sintaxis de ejecución: ejercicio5-maestro <a> <b>\n");
        exit(EXIT_FAILURE);
    }

    // [min, max] -> [min, mid] & [mid+1, max]
    int min = atoi(argv[1]), max = atoi(argv[2]);
    int mid = (min + max) / 2;
    sprintf(mid_c, "%d", mid);
    sprintf(mid1_c, "%d", mid+1);

    // E1 & E2 -> M
    pipe(fd); 

    // Ejecución y creación esclavo 1
    if ((esclavo_1 = fork()) == 0){
        close(fd[0]); 
        dup2(fd[1], STDOUT_FILENO);

        // Para que al comenzar a trabajar el esclavo 2 el 1 no haya terminado
        sleep(0.001); 
        execl("./ejercicio5-esclavo", "ejercicio5-esclavo", argv[1], mid_c, NULL);
    }
    // Ejecución y creación esclavo 2
    else if ((esclavo_2 = fork()) == 0){
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);

        execl("./ejercicio5-esclavo", "ejercicio5-esclavo", mid1_c, argv[2], NULL);
    }
    // Ejecución maestro
    else{
        close(fd[1]);

        while (read(fd[0], &primo, sizeof(int)) != 0)
            printf("%d\n", primo);
    }

    return EXIT_SUCCESS;
}
```

```c
/**
 * @file ejercicio5-esclavo.c
 */

#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <math.h>

int esPrimo(int num);

int main(int argc, char* argv[]){
    char primo_c[20];

    if (argc != 3){
        printf("Sintaxis de ejecución: ejercicio5-esclavo <a> <b>\n");
        exit(EXIT_FAILURE);
    }
    
    int min = atoi(argv[1]), max = atoi(argv[2]);
    for (int candidato = min; candidato <= max; ++candidato)
        if (esPrimo(candidato))
            write(STDOUT_FILENO, &candidato, sizeof(int));

    return EXIT_SUCCESS;
}

int esPrimo(int num){
    char primo_c[10];
    for (int i = 2; i <= sqrt(num); ++i)
        if (num % i == 0)
            return 0;

    return 1;
}
```

