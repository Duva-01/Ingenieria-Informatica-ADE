/**
 * @file figura1-original.c
 * @author Daniel Pérez Ruiz
 * @brief Implementacion del codigo de la figura1 sin cambios
 *
 * Compilacion: gcc -O2 figura1-original.c -o figura1-original
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * @brief Struct de la figura1 implementado
 */
struct {
    int a;
    int b;
} s[5000];

int main(int argc, char * argv[]){
    //VARIABLES PARA EL CALCULO DEL TIEMPO
    struct timespec cgt1,cgt2;
    double ncgt;

    //VARIABLES PARA LOS CALCULOS
    double R[40000];
    int ii; double X1, X2;

    //INICIALIZACION DEL STRUCT
    for(ii = 0; ii<5000; ii++){
        s[ii].a = ii;
        s[ii].b = ii+5;
    }

    //CALCULO DE TIEMPO DE EJECUCION...
    clock_gettime(CLOCK_REALTIME,&cgt1);
    for(ii = 0; ii<40000; ii++){
        X1 = 0; X2 = 0;
        for(int i=0; i<5000; i++) X1 += 2*s[i].a+ii;
        for(int i=0; i<5000; i++) X2 += 3*s[i].b-ii;

        if(X1 < X2) R[ii]=X1; else R[ii] = X2;
    }
    clock_gettime(CLOCK_REALTIME,&cgt2);

    ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+(double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));

    //MOSTRANDO POR PANTALLA RESULTADOS (5 PRIMEROS Y 5 ÚLTIMOS)
    printf(">> MOSTRANDO RESULTADOS <<\n --> PRIMEROS 5...\n");
    for(ii = 0; ii<5; ii++){
        printf("\t \t R[%d] = %f\n",ii, R[ii]);
    }
    printf(" --> ULTIMOS 5... \n");
    for(ii = 4; ii>=0; ii--){
        printf("\t \t R[%d] = %f\n",39999-ii, R[39999-ii]);
    }

    //MOSTRANDO POR PANTALLA TIEMPO DE EJECUCION
    printf("\n>> TIEMPO DE EJECUCION: %11.9f\n", ncgt);

    return EXIT_SUCCESS;
}
