// Nombre: David Apellidos: Martinez Diaz Titulación: GIADE.
// email: dmartinez01@correo.ugr.es DNI o pasaporte: 44669141J

// *********************************************************************
// **
// ** Gestión de una grafo de escena (implementación)
// ** Copyright (C) 2016 Carlos Ureña
// **
// ** This program is free software: you can redistribute it and/or modify
// ** it under the terms of the GNU General Public License as published by
// ** the Free Software Foundation, either version 3 of the License, or
// ** (at your option) any later version.
// **
// ** This program is distributed in the hope that it will be useful,
// ** but WITHOUT ANY WARRANTY; without even the implied warranty of
// ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ** GNU General Public License for more details.
// **
// ** You should have received a copy of the GNU General Public License
// ** along with this program.  If not, see <http://www.gnu.org/licenses/>.
// **
// *********************************************************************

#include "ig-aux.h"
#include "grafo-escena.h"
#include "malla-ind.h"
#include "malla-revol.h"

using namespace std ;

// *********************************************************************
// Entrada del nodo del Grafo de Escena

// ---------------------------------------------------------------------
// Constructor para entrada de tipo sub-objeto

EntradaNGE::EntradaNGE( Objeto3D * pObjeto )
{
   assert( pObjeto != NULL );
   tipo   = TipoEntNGE::objeto ;
   objeto = pObjeto ;
}
// ---------------------------------------------------------------------
// Constructor para entrada de tipo "matriz de transformación"

EntradaNGE::EntradaNGE( const Matriz4f & pMatriz )
{
   tipo    = TipoEntNGE::transformacion ;
   matriz  = new Matriz4f() ; // matriz en el heap, puntero propietario
   *matriz = pMatriz ;
}

// ---------------------------------------------------------------------
// Constructor para entrada de tipo "matriz de transformación"

EntradaNGE::EntradaNGE( Material * pMaterial )
{
   assert( pMaterial != NULL );
   tipo     = TipoEntNGE::material ;
   material = pMaterial ;
}

// -----------------------------------------------------------------------------
// Destructor de una entrada

EntradaNGE::~EntradaNGE()
{
   /**  no fnciona debido a que se hacen copias (duplicados) de punteros
   if ( tipo == TipoEntNGE::transformacion )
   {
      assert( matriz != NULL );
      delete matriz ;
      matriz = NULL ;
   }
   * **/
}

// *****************************************************************************
// Nodo del grafo de escena: contiene una lista de entradas
// *****************************************************************************

// -----------------------------------------------------------------------------
// Visualiza usando OpenGL

void NodoGrafoEscena::visualizarGL( ContextoVis & cv )
{
   // COMPLETAR: práctica 3: recorrer las entradas y visualizar cada nodo.
   
   // guarda modelview actual

   Material * material_pre = cv.material_act;

   cv.cauce->pushMM();
   const Tupla4f color_previo = leerFijarColVertsCauce(cv);

   for( unsigned i = 0 ; i < entradas.size() ; i++ ){

      switch( entradas[i].tipo ){ 

         case TipoEntNGE::objeto : // entrada objeto:
            entradas[i].objeto->visualizarGL( cv ); // visualizar objeto
         break ;
         case TipoEntNGE::transformacion : // entrada transf.:
            cv.cauce->compMM( *(entradas[i].matriz)); // componer matriz
         break ;

         case TipoEntNGE::material :

            // COMPLETAR: práctica 4: en la práctica 4, si 'cv.iluminacion' es 'true',
            // se deben de gestionar los materiales:
            //   1. guardar puntero al material activo al inicio (está en cv.material_act)
            //   2. si una entrada des de tipo material, activarlo y actualizar 'cv.material_act'
            //   3. al finalizar, restaurar el material activo al inicio (si es distinto del actual)

            if(cv.iluminacion){
               
               entradas[i].material->activar(cv);
            }
         break;

         case TipoEntNGE::noInicializado :

         break;
      }



   }

   // restaura modelview guardada
   cv.cauce->fijarColor( color_previo );
   cv.cauce->popMM() ;

   if ( material_pre != nullptr ){
      cv.material_act = material_pre ; // copiar el previo en ’cv’
      cv.material_act->activar( cv ); // activar el previo
   }
}


// *****************************************************************************
// visualizar pura y simplemente la geometría, sin colores, normales, coord. text. etc...

void NodoGrafoEscena::visualizarGeomGL( ContextoVis & cv )
{
   // comprobar que hay un cauce en 'cv' 
   assert( cv.cauce != nullptr );
  

   // COMPLETAR: práctica 3
   //
   // Este método hace un recorrido de las entradas del nodo, parecido a 'visualizarGL', teniendo 
   // en cuenta estos puntos:
   //
   // - usar push/pop de la matriz de modelado al inicio/fin (al igual que en visualizatGL)
   // - recorrer las entradas, llamando recursivamente a 'visualizarGeomGL' en los nodos u objetos hijos
   // - ignorar el color o identificador del nodo (se supone que el color ya está prefijado antes de la llamada)
   // - ignorar las entradas de tipo material, y la gestión de materiales (se usa sin iluminación)

   // guarda modelview actual
   cv.cauce->pushMM();

   for( unsigned i = 0 ; i < entradas.size() ; i++ ){

      switch( entradas[i].tipo ){ 

         case TipoEntNGE::objeto : // entrada objeto:
            entradas[i].objeto->visualizarGeomGL( cv ); // visualizar objeto
         break ;
         case TipoEntNGE::transformacion : // entrada transf.:
            cv.cauce->compMM( *(entradas[i].matriz)); // componer matriz
         break ;

         case TipoEntNGE::material :

         break;

         case TipoEntNGE::noInicializado :

         break;
      }

   }

   // restaura modelview guardada
   cv.cauce->popMM() ;

}

// -----------------------------------------------------------------------------

NodoGrafoEscena::NodoGrafoEscena()
{

}

// -----------------------------------------------------------------------------
// Añadir una entrada (al final).
// genérica (de cualqiuer tipo de entrada)

unsigned NodoGrafoEscena::agregar( const EntradaNGE & entrada )
{
   // COMPLETAR: práctica 3: agregar la entrada al nodo, devolver índice de la entrada agregada
   // ........
   entradas.push_back(entrada);
   return entradas.size()-1; // sustituir por lo que corresponda ....

}
// -----------------------------------------------------------------------------
// construir una entrada y añadirla (al final)
// objeto (copia solo puntero)

unsigned NodoGrafoEscena::agregar( Objeto3D * pObjeto )
{
   return agregar( EntradaNGE( pObjeto ) );
}
// ---------------------------------------------------------------------
// construir una entrada y añadirla (al final)
// matriz (copia objeto)

unsigned NodoGrafoEscena::agregar( const Matriz4f & pMatriz )
{
   return agregar( EntradaNGE( pMatriz ) );
}
// ---------------------------------------------------------------------
// material (copia solo puntero)
unsigned NodoGrafoEscena::agregar( Material * pMaterial )
{
   return agregar( EntradaNGE( pMaterial ) );
}

// devuelve el puntero a la matriz en la i-ésima entrada
Matriz4f * NodoGrafoEscena::leerPtrMatriz( unsigned indice )
{
   // COMPLETAR: práctica 3: devolver puntero la matriz en ese índice
   //   (debe de dar error y abortar si no hay una matriz en esa entrada)
   // ........(sustituir 'return nullptr' por lo que corresponda)
   assert( indice < entradas.size() );
   assert( entradas[indice].tipo == TipoEntNGE::transformacion );
   assert( entradas[indice].matriz != nullptr );

   return entradas[indice].matriz ;
}
// -----------------------------------------------------------------------------
// si 'centro_calculado' es 'false', recalcula el centro usando los centros
// de los hijos (el punto medio de la caja englobante de los centros de hijos)

void NodoGrafoEscena::calcularCentroOC()
{

   // COMPLETAR: práctica 5: calcular y guardar el centro del nodo
   //    en coordenadas de objeto (hay que hacerlo recursivamente)
   //   (si el centro ya ha sido calculado, no volver a hacerlo)
   // ........

   Matriz4f matriz_t=MAT_Ident();
   int contador=0;

   if(!centro_calculado){

      centro_calculado=true;
      Tupla3f centro_nodo=this->leerCentroOC();


      for(int i=0;i<entradas.size();i++){
         if(entradas[i].tipo == TipoEntNGE::objeto){
            entradas[i].objeto->calcularCentroOC();
            centro_nodo=centro_nodo+entradas[i].objeto->leerCentroOC();
            contador++;
         }
         else if(entradas[i].tipo == TipoEntNGE::transformacion){
            matriz_t=matriz_t*(*entradas[i].matriz);
         }
      }

      centro_nodo=centro_nodo/contador;
      centro_nodo=matriz_t*centro_nodo;
      
      this->ponerCentroOC(centro_nodo);

   }
}
// -----------------------------------------------------------------------------
// método para buscar un objeto con un identificador y devolver un puntero al mismo

bool NodoGrafoEscena::buscarObjeto
(
   const int         ident_busc, // identificador a buscar
   const Matriz4f &  mmodelado,  // matriz de modelado
   Objeto3D       ** objeto,     // (salida) puntero al puntero al objeto
   Tupla3f &         centro_wc   // (salida) centro del objeto en coordenadas del mundo
)
{
   assert( 0 < ident_busc );

   // COMPLETAR: práctica 5: buscar un sub-objeto con un identificador
   // Se deben de dar estos pasos:

   // 1. calcula el centro del objeto, (solo la primera vez)
   // ........
   calcularCentroOC();

   // 2. si el identificador del nodo es el que se busca, ya está (terminar)
   // ........
   if(ident_busc == this->leerIdentificador()){
      centro_wc=mmodelado * this->leerCentroOC();
      *objeto=this;
      return true;
   }

   // 3. El nodo no es el buscado: buscar recursivamente en los hijos
   //    (si alguna llamada para un sub-árbol lo encuentra, terminar y devolver 'true')
   // ........
   Matriz4f matriz_t=mmodelado;

   for(int i=0;i<entradas.size();i++){
         if(entradas[i].tipo == TipoEntNGE::objeto){

            if(entradas[i].objeto->buscarObjeto(ident_busc,matriz_t,objeto,centro_wc)){
               return true;
            }
         }
         else if(entradas[i].tipo == TipoEntNGE::transformacion){
            matriz_t=matriz_t*(*entradas[i].matriz);
         }
   }


   // ni este nodo ni ningún hijo es el buscado: terminar
   return false ;
}

// Ejercicios adicionales Practica 3

ConoUbicado::ConoUbicado(unsigned n, float X, float Y, float Z, float angulo_rotacion, float escalado_X, float escalado_Y, float escalado_Z){

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion-90, {0.0, 0.0, 1.0}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));
   agregar(new Cono(3, 15, 1));

}

ConosEstrella::ConosEstrella(unsigned n){

   float X_picos, Y_picos;

   float angulo_incr = 360/n;
   float angulo = 360/n;

   for(int i=0; i<n; i++){

      X_picos = 1.3*cos( angulo*M_PI/180 );
      Y_picos = 1.3*sin( angulo*M_PI/180 );

      std::cout << "Agrego el cono en la posicion: " << X_picos << ", " << Y_picos << " con un angulo de " << angulo << std::endl;
      agregar(new ConoUbicado(n, X_picos, Y_picos, 0.0, angulo, 0.07, 0.15, 0.07));
      angulo += angulo_incr;
   }

}

GrafoEstrellaX::GrafoEstrellaX(unsigned n){

   int indice = agregar(MAT_Rotacion((0.0), {1.0, 0.0, 0.0}));

   agregar(MAT_Rotacion((90.0), {0.0, 1.0, 0.0}));
   agregar(new ConosEstrella(n));

   agregar(MAT_Escalado(2.6, 2.6, 2.6));
   agregar( MAT_Traslacion( {-0.5,-0.5,0.0} ) );

   
   agregar( new EstrellaZ(n) );

   rotacion = leerPtrMatriz(indice);
}

unsigned GrafoEstrellaX::leerNumParametros() const{
    
   return 1;
}

// Redefinimos metodo actualizarEstadoParametro()
void GrafoEstrellaX::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         *rotacion = MAT_Rotacion((360*2.5 * tSec), {1.0, 0.0, 0.0});
      break;
   
   default:
         *rotacion = MAT_Rotacion((360*2.5 * tSec), {1.0, 0.0, 0.0});
      break;
   }

}

// Ejercicio 2 

RejillaUbicada::RejillaUbicada(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z){

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(new RejillaY(10,10));
}

CuboRejilla::CuboRejilla() {
   
   agregar( new RejillaUbicada(-0.5, -0.5, -0.5, 90, 0.0, 0.0, 1.0)); // Eje Z
   agregar( new RejillaUbicada(0.5, -0.5, -0.5, 90, 0.0, 0.0, 1.0)); // Eje Z

   agregar( new RejillaUbicada(-0.5, 0.5, -0.5, 0, 0.0, 1.0, 0.0)); // Eje Y
   agregar( new RejillaUbicada(-0.5, -0.5, -0.5, 0, 0.0, 1.0, 0.0)); // Eje Y

   agregar( new RejillaUbicada(-0.5, 0.5, -0.5, 90, 1.0, 0.0, 0.0)); // Eje X
   agregar( new RejillaUbicada(-0.5, 0.5, 0.5, 90, 1.0, 0.0, 0.0)); // Eje X

}

//----------------------

CuboUbicado::CuboUbicado(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z) {
   
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   
   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   if(X != 0.0){
      eje = 0;
   }
   else if(Y != 0.0) {
      eje = 1;
   }
   else {
      eje = 2;
   }

   agregar(new Cubo(1.0, 1.0, 1.0));

   rotacion = leerPtrMatriz(indice);
   
}


unsigned CuboUbicado::leerNumParametros() const{
    
   return 1;
}

void CuboUbicado::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         switch (eje)
         {
         case 0:
            * rotacion = MAT_Rotacion((100*tSec), {1.0, 0.0, 0.0});
            break;
         
         case 1:
            * rotacion = MAT_Rotacion((100*tSec), {0.0, 1.0, 0.0});
            break;

         case 2:
            * rotacion = MAT_Rotacion((100*tSec), {0.0, 0.0, 1.0});
            break;

         default:
            break;
         }
      break;
   
   default:
      break;
   }

}

//-------------------------------------------

MiniCubosRejilla::MiniCubosRejilla(){

   //int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

   c1 =  new CuboUbicado(0.0, 0.75, 0.0, 0, 0.0, 0.0, 1.0, 0.1, 0.25, 0.1);
   c2 = new CuboUbicado(0.0, -0.75, 0.0, 0, 0.0, 0.0, 1.0, 0.1, 0.25, 0.1);
   agregar(c1); // Eje Y
   agregar( c2); // Eje Y

   c3 = new CuboUbicado(-0.75, 0.0, 0.0, 90, 0.0, 0.0, 1.0, 0.1, 0.25, 0.1);
   c4 = new CuboUbicado(0.75, 0.0, 0.0, 90, 0.0, 0.0, 1.0, 0.1, 0.25, 0.1);
   agregar( c3); // Eje X
   agregar( c4); // Eje X

   c5 = new CuboUbicado(0.0, 0.0, -0.75, 90, 1.0, 0.0, 0.0, 0.1, 0.25, 0.1);
   c6 =  new CuboUbicado(0.0, 0.0, 0.75, 90, 1.0, 0.0, 0.0, 0.1, 0.25, 0.1);
   agregar(c5 ); // Eje Z
   agregar(c6); // Eje Z
   
}

unsigned MiniCubosRejilla::leerNumParametros() const{
    
   return 1;
}

void MiniCubosRejilla::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         c1->actualizarEstadoParametro(iParam, tSec);
         c2->actualizarEstadoParametro(iParam, tSec);
         c3->actualizarEstadoParametro(iParam, tSec);
         c4->actualizarEstadoParametro(iParam, tSec);
         c5->actualizarEstadoParametro(iParam, tSec);
         c6->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         c1->actualizarEstadoParametro(iParam, tSec);
         c2->actualizarEstadoParametro(iParam, tSec);
         c3->actualizarEstadoParametro(iParam, tSec);
         c4->actualizarEstadoParametro(iParam, tSec);
         c5->actualizarEstadoParametro(iParam, tSec);
         c6->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

//---------------------



//-----------------------

GrafoCubos::GrafoCubos(){
   
   agregar(new CuboRejilla() );

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   cubillos = new MiniCubosRejilla();
   agregar(cubillos);

   rotacion = leerPtrMatriz(indice);
}

unsigned GrafoCubos::leerNumParametros() const{
    
   return 1;
}

void GrafoCubos::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         cubillos->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         cubillos->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

// Ejercicios para practicar 

// Examen Sombrilla

Sombrilla::Sombrilla(){

   soporte = new Soporte(5);
   agregar (soporte);
   

}

unsigned Sombrilla::leerNumParametros() const{
    
   return 1;
}

void Sombrilla::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         soporte->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         soporte->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

Varilla::Varilla(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z){


   agregar(MAT_Traslacion({X, Y, Z}));

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   agregar(MAT_Traslacion({1, 0, 0}));
   agregar(new Cubo(0.5, 0.7, 0.8));

   rotacion = leerPtrMatriz(indice);
}

unsigned Varilla::leerNumParametros() const{
    
   return 1;
}

void Varilla::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
      if(sin(tSec)*90 < 0)
         * rotacion = MAT_Rotacion(sin(tSec)*90, {0.0, 0.0, 1.0});
      break;
   
   default:
         * rotacion = MAT_Rotacion(sin(tSec), {0.0, 0.0, 1.0});
      break;
   }

}

Soporte::Soporte(int n){

   float angulo_incr = 360/n;

   //----------------------------------

   for(int i = 0; i<n; i++){

   }

   agregar(MAT_Rotacion(angulo_incr, {0, 1, 0}));
   v1 = new Varilla(1, 15, 0, 0, 0, 0, 1, 10, 1, 1);
   agregar(v1);

   agregar(MAT_Rotacion(angulo_incr, {0, 1, 0}));
   v2 = new Varilla(1, 15, 0, 0, 0, 0, 1, 10, 1, 1);
   agregar(v2);

   agregar(MAT_Rotacion(angulo_incr, {0, 1, 0}));
   v3 = new Varilla(1, 15, 0, 0, 0, 0, 1, 10, 1, 1);
   agregar(v3);

   agregar(MAT_Rotacion(angulo_incr, {0, 1, 0}));
   v4 = new Varilla(1, 15, 0, 0, 0, 0, 1, 10, 1, 1);
   agregar(v4);

   agregar(MAT_Rotacion(angulo_incr, {0, 1, 0}));
   v5 = new Varilla(1, 15, 0, 0, 0, 0, 1, 10, 1, 1);
   agregar(v5);

   //-------------------------------------

   agregar(MAT_Escalado(1, 15, 1));
   agregar(new Cilindro(30,30, {1,0,0}));

}

unsigned Soporte::leerNumParametros() const{
    
   return 1;
}

void Soporte::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         v1->actualizarEstadoParametro(iParam, tSec);
         v2->actualizarEstadoParametro(iParam, tSec);
         v3->actualizarEstadoParametro(iParam, tSec);
         v4->actualizarEstadoParametro(iParam, tSec);
         v5->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         v1->actualizarEstadoParametro(iParam, tSec);
         v2->actualizarEstadoParametro(iParam, tSec);
         v3->actualizarEstadoParametro(iParam, tSec);
         v4->actualizarEstadoParametro(iParam, tSec);
         v5->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

//-------------------------------------------

// Examen Donuts

AroUbicado::AroUbicado(float X, float Y, float Z, float angulo_rotacion, float rot_X, float rot_Y, float rot_Z, float escalado_X, float escalado_Y, float escalado_Z, float radio_int, float radio_aro, float a, float b, float c){

   if(X == 0){
      eje = 0;
   }
   else if (X == 3){
      eje = 1;
   }
   else {
      eje = 2;
   }
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

   agregar(MAT_Traslacion({X, Y, Z}));
   agregar(MAT_Rotacion(angulo_rotacion, {rot_X, rot_Y, rot_Z}));
   agregar(MAT_Escalado(escalado_X, escalado_Y, escalado_Z));

   agregar(MAT_Traslacion({0, -radio_int, 0}));
   agregar(new Aro(30, 30, radio_int, radio_aro, a, b, c));

   rotacion = leerPtrMatriz(indice);
}

unsigned AroUbicado::leerNumParametros() const{
    
   return 1;
}

void AroUbicado::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
      
      switch (eje)
      {
      case 0:
         /* code */
         break;
      case 1:
         * rotacion = MAT_Rotacion(tSec*30, {1.0, 0.0, 0.0});
         break;
      
      case 2:
         * rotacion = MAT_Rotacion(-tSec*30, {1.0, 0.0, 0.0});
         break;
      
      default:
         break;
      }
         
      break;
   
   default:
         * rotacion = MAT_Rotacion(sin(tSec), {0.0, 0.0, 1.0});
      break;
   }

}

MultiplesAros::MultiplesAros(){

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

    a1 = new AroUbicado(0,0,0, 90, 1, 0, 0, 1, 1, 1, 6.5, 0.5, 1, 0, 0);
    agregar(a1);
    a2 = new AroUbicado(3.0,0,0, 90, 1, 0, 0, 1, 1, 1, 2.5, 0.5, 0, 1, 0);
    agregar(a2);
    a3 = new AroUbicado(-3.0,0,0, 90, 1, 0, 0, 1, 1, 1, 2.5, 0.5, 0, 0, 1);
    agregar(a3);

    rotacion = leerPtrMatriz(indice);
}

unsigned MultiplesAros::leerNumParametros() const{
    
   return 1;
}

void MultiplesAros::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * rotacion = MAT_Rotacion(tSec*30, {0.0, 1.0, 0.0});
         a1->actualizarEstadoParametro(iParam, tSec);
         a2->actualizarEstadoParametro(iParam, tSec);
         a3->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         * rotacion = MAT_Rotacion(sin(tSec), {0.0, 0.0, 1.0});
      break;
   }

}

//------------------

// Examen escavadora

//---------------------------

SegundoGanchoExcavadora::SegundoGanchoExcavadora(Tupla3f traslacion, float angulo_rotacion, Tupla3f rotacion, Tupla3f escalado){
   
   
   agregar(MAT_Traslacion(traslacion));
   
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   
   agregar(MAT_Rotacion(angulo_rotacion, rotacion));
   agregar(MAT_Escalado(escalado(0), escalado(1), escalado(2)));

   agregar(MAT_Traslacion({6, 0, 0}));
   agregar(new Cubo({0.3,0.3,0.3}));

   rotacionPrimerGancho = leerPtrMatriz(indice);
}

unsigned SegundoGanchoExcavadora::leerNumParametros() const{
    
   return 1;
}

void SegundoGanchoExcavadora::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * rotacionPrimerGancho = MAT_Rotacion(sin(tSec)*16, {0.0, 0.0, 1.0});
         
      break;
   
   default:
         * rotacionPrimerGancho = MAT_Rotacion(sin(tSec)*16, {0.0, 0.0, 1.0});
      break;
   }

}

//---------------------------

PrimerGanchoExcavadora::PrimerGanchoExcavadora(Tupla3f traslacion, float angulo_rotacion, Tupla3f rotacion, Tupla3f escalado){
   
   
   agregar(MAT_Traslacion(traslacion));
   
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   agregar(MAT_Rotacion(angulo_rotacion, rotacion));
   agregar(MAT_Escalado(escalado(0), escalado(1), escalado(2)));
   
   agregar(MAT_Traslacion({1, 0, 0}));
   agregar(new Cubo({0,1,0}));

   rotacionPrimerGancho = leerPtrMatriz(indice);
}

unsigned PrimerGanchoExcavadora::leerNumParametros() const{
    
   return 1;
}

void PrimerGanchoExcavadora::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * rotacionPrimerGancho = MAT_Rotacion(sin(tSec)*20, {0.0, 0.0, 1.0});
         
      break;
   
   default:
         * rotacionPrimerGancho = MAT_Rotacion(sin(tSec)*20, {0.0, 0.0, 1.0});
      break;
   }

}

//---------------------------

GanchoExcavadora::GanchoExcavadora(){
   
   primerGanchoExcavadora = new PrimerGanchoExcavadora({0,6,0}, 0, {1,0,0}, {4,0.2,0.2});
   segundoGancho = new SegundoGanchoExcavadora({-2,6,0}, 0, {1,0,0}, {2,0.2,0.2});

   agregar(primerGanchoExcavadora);
   agregar(segundoGancho);

}

unsigned GanchoExcavadora::leerNumParametros() const{
    
   return 1;
}

void GanchoExcavadora::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         primerGanchoExcavadora->actualizarEstadoParametro(iParam, tSec);
         segundoGancho->actualizarEstadoParametro(iParam, tSec);
         
      break;
   
   default:
         primerGanchoExcavadora->actualizarEstadoParametro(iParam, tSec);
         segundoGancho->actualizarEstadoParametro(iParam, tSec);

      break;
   }

}

//---------------------------

ParteArribaExcavadora::ParteArribaExcavadora(){

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

   agregar(new ObjetoModificable({0,6,0}, 0, {1,0,0}, {1,1,1}, * new Cubo({0,0,1})));
   ganchoExcavadora = new GanchoExcavadora();
   agregar(ganchoExcavadora);

   rotacion = leerPtrMatriz(indice);
}

unsigned ParteArribaExcavadora::leerNumParametros() const{
    
   return 1;
}

void ParteArribaExcavadora::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         ganchoExcavadora->actualizarEstadoParametro(iParam, tSec);
         * rotacion = MAT_Rotacion(tSec*30, {0.0, 1.0, 0.0});
         
      break;
   
   default:
         ganchoExcavadora->actualizarEstadoParametro(iParam, tSec);
         * rotacion = MAT_Rotacion(tSec*30, {0.0, 0.0, 1.0});
      break;
   }

}


//---------------------------

Excavadora::Excavadora(){

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

   agregar(new ObjetoModificable({2, 0, -0.5}, 90, {1,0,0}, {1,1,1}, * new Cilindro(30, 30, {0,0,0})));
   agregar(new ObjetoModificable({-2, 0, -0.5}, 90, {1,0,0}, {1,1,1}, * new Cilindro(30, 30, {0,0,0})));

   agregar(new ObjetoModificable({0,3,0}, 0, {1,0,0}, {4,2,2}, * new Cubo({1,0,0})));

   parteArriba = new ParteArribaExcavadora();
   agregar(parteArriba);

   traslacion = leerPtrMatriz(indice);
   
}

unsigned Excavadora::leerNumParametros() const{
    
   return 1;
}

void Excavadora::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * traslacion = MAT_Traslacion({sin(tSec)*5, 0, 0});
         parteArriba->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         * traslacion = MAT_Traslacion({sin(tSec)*5, 0, 0});
         parteArriba->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

// Ejercicio tipo de examen

RuedasCoche::RuedasCoche(Tupla3f traslacion, float angulo_rotacion, Tupla3f rotacion, Tupla3f escalado){
   
   agregar(MAT_Traslacion(traslacion));
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 0.0, 1.0}));
   
   agregar(MAT_Rotacion(angulo_rotacion, rotacion));
   agregar(MAT_Escalado(escalado(0), escalado(1), escalado(2)));

   agregar(new Cilindro(15,15, {1,1,1}));
   rotacionRueda = leerPtrMatriz(indice);
   
}

unsigned RuedasCoche::leerNumParametros() const{
    
   return 1;
}

void RuedasCoche::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * rotacionRueda = MAT_Rotacion(tSec*20, {0.0, 0.0, 1.0});
         
      break;
   
   default:
         * rotacionRueda = MAT_Rotacion(tSec*20, {0.0, 0.0, 1.0});
         
      break;
   }

}

Coche::Coche(){

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   agregar(MAT_Traslacion({0.0, 0.0, 6.0}));

   agregar(new ObjetoModificable({0, 0, 0}, 0, {1,0,0}, {2,1,1}, * new Cubo({1,0,0})));
   agregar(new ObjetoModificable({0, 1.5, 0}, 0, {1,0,0}, {1,0.5,1}, * new Cubo({1,1,0})));

   r1 = new RuedasCoche({2,-0.5, 1}, 90, {1,0,0}, {1,1,1});
   r2 = new RuedasCoche({2,-0.5, -2}, 90, {1,0,0}, {1,1,1});
   r3 = new RuedasCoche({-2,-0.5, 1}, 90, {1,0,0}, {1,1,1});
   r4 = new RuedasCoche({-2,-0.5, -2}, 90, {1,0,0}, {1,1,1});
   agregar(r1);
   agregar(r2);
   agregar(r3);
   agregar(r4);

   rotacion = leerPtrMatriz(indice);
   
}

unsigned Coche::leerNumParametros() const{
    
   return 1;
}

void Coche::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * rotacion = MAT_Rotacion(tSec*20, {0.0, 1.0, 0.0});
         r1->actualizarEstadoParametro(iParam, tSec);
         r2->actualizarEstadoParametro(iParam, tSec);
         r3->actualizarEstadoParametro(iParam, tSec);
         r4->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         * rotacion = MAT_Rotacion(tSec*20, {0.0, 1.0, 0.0});
         r1->actualizarEstadoParametro(iParam, tSec);
         r2->actualizarEstadoParametro(iParam, tSec);
         r3->actualizarEstadoParametro(iParam, tSec);
         r4->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

// Ejercicio de examen 3


ObjetoModificable::ObjetoModificable(Tupla3f traslacion, float angulo_rotacion, Tupla3f rotacion, Tupla3f escalado, Objeto3D & ObjetoModificable){

   agregar(MAT_Traslacion(traslacion));
   agregar(MAT_Rotacion(angulo_rotacion, rotacion));
   agregar(MAT_Escalado(escalado(0), escalado(1), escalado(2)));

   agregar(& ObjetoModificable);
}

Tramo::Tramo(Tupla3f traslacion, float angulo_rotacion, Tupla3f rotacion, Tupla3f escalado){

   agregar(MAT_Traslacion(traslacion));
   agregar(MAT_Rotacion(angulo_rotacion, rotacion));
   agregar(MAT_Escalado(escalado(0), escalado(1), escalado(2)));

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

   agregar(new ObjetoModificable({0, 0, 0}, 0, {1,0,0}, {0.3,2,0.3}, * new Cilindro(30,30, {1,1,1})));
   agregar(new ObjetoModificable({0, 2, 0}, 0, {1,0,0}, {0.3,0.3,0.3}, * new Esfera(30,30)));
   
   rotacionTramo = leerPtrMatriz(indice);
   
}

unsigned Tramo::leerNumParametros() const{
    
   return 1;
}

void Tramo::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         * rotacionTramo = MAT_Rotacion(tSec*360/5, {0.0, 1.0, 0.0});
         
      break;
   
   default:
         * rotacionTramo = MAT_Rotacion(tSec*360/5, {0.0, 1.0, 0.0});
      break;
   }

}
//----------------------------------------------------

UltimoTramo::UltimoTramo(){

   int indice = agregar(MAT_Traslacion({0,0,0}));
   
   t3 = new Tramo({0, 3, 2}, 180, {1,0,0}, {1,1,1});
   agregar(t3);
   
   traslacionUltimoTramo = leerPtrMatriz(indice);
   
}

unsigned UltimoTramo::leerNumParametros() const{
    
   return 1;
}

void UltimoTramo::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         if(sin(tSec) > 0.6){
         * traslacionUltimoTramo = MAT_Traslacion({1, 1, (sin(tSec)+0.1)*10});
         }
         t3->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         if(sin(tSec) > 0.6){
         * traslacionUltimoTramo = MAT_Traslacion({1, 1, (sin(tSec)+0.1)*10});
      }
         t3->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

//----------------------------------------------------

BrazoTramo::BrazoTramo(){

   
   agregar(MAT_Traslacion({0,3,0}));

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

   agregar(MAT_Traslacion({0,-3,0}));

   ultimoTramo = new UltimoTramo();
   agregar(ultimoTramo);

   t3 = new Tramo({0, 3, 2}, 180, {1,0,0}, {1,1,1});
   agregar(t3);

   int indice2 = agregar(MAT_Escalado(1,1,1));

   t2 = new Tramo({0, 3, 0}, 90, {1,0,0}, {1,1,1});
   agregar(t2);
   
   escaladoTramo = leerPtrMatriz(indice2);
   rotacionBrazoTramo = leerPtrMatriz(indice);
   
}

unsigned BrazoTramo::leerNumParametros() const{
    
   return 1;
}

void BrazoTramo::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
      if(sin(tSec)*80 < 0){
         * rotacionBrazoTramo = MAT_Rotacion(sin(tSec)*80, {1.0, 0.0, 0.0});
      }
      if(sin(tSec) > 0.6){
         * escaladoTramo = MAT_Escalado(1, 1, sin(tSec)+0.1);
      }
         
         t2->actualizarEstadoParametro(iParam, tSec);
         ultimoTramo->actualizarEstadoParametro(iParam, tSec);
         t3->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         if(sin(tSec)*80 < 0){
         * rotacionBrazoTramo = MAT_Rotacion(sin(tSec)*80, {1.0, 0.0, 0.0});
      }
      if(sin(tSec) > 0.6){
         * escaladoTramo = MAT_Escalado(1, 1,sin(tSec)+0.1);
      }
         t2->actualizarEstadoParametro(iParam, tSec);
         ultimoTramo->actualizarEstadoParametro(iParam, tSec);
         t3->actualizarEstadoParametro(iParam, tSec);
      break;
   }

}

//------------------------------------------

Articulado::Articulado(){

   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   
   brazo = new BrazoTramo();
   t1 = new Tramo({0, 1, 0}, 0, {1,0,0}, {1,1,1});
   
   agregar(brazo);
   agregar(t1);

   agregar(new ObjetoModificable({0, 0.5, 0}, 0, {1,0,0}, {0.5,0.5,0.5}, * new Cubo({1,0,0})));


   rotacion = leerPtrMatriz(indice);
   
}

unsigned Articulado::leerNumParametros() const{
    
   return 1;
}

void Articulado::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:
         //* rotacion = MAT_Rotacion(tSec*20, {0.0, 1.0, 0.0});
         t1->actualizarEstadoParametro(iParam, tSec);
         brazo->actualizarEstadoParametro(iParam, tSec);
         
      break;
   
   default:
         //* rotacion = MAT_Rotacion(tSec*20, {0.0, 1.0, 0.0});
         t1->actualizarEstadoParametro(iParam, tSec);
         brazo->actualizarEstadoParametro(iParam, tSec);
         
      break;
   }

}

// --------------------------------------------------------
// Practica 4

NodoLata::NodoLata(std::string & nombre_textura, float p_k_amb, float p_k_dif, float p_k_pse, float p_exp_pse)
{

   Textura *textura;
   if( nombre_textura != ""){
        textura = new Textura(nombre_textura);
        agregar(new Material(textura, p_k_amb, p_k_dif, p_k_pse, p_exp_pse));
   }
   else {
        agregar(new Material(p_k_amb, p_k_dif, p_k_pse, p_exp_pse));
   }
   
   agregar(new MallaRevolPLY("lata-pcue.ply", 25));

   Material *mat_tapas = new Material(0.4, 0.4, 12, 140);

   agregar(mat_tapas);
   agregar(new MallaRevolPLY("lata-psup.ply", 25));
   agregar(new MallaRevolPLY("lata-pinf.ply", 25)); 

}

NodoCubo24::NodoCubo24()
{
   Textura *ugr = new Textura("window-icon.jpg");

   agregar(new Material(ugr, 0.8, 0.8, 12, 140));
   agregar(new Cubo24());

}

NodoDiscoP4::NodoDiscoP4()
{
   ponerNombre("Nodo ejercicio adicional práctica 4, examen 27 enero");
   
   Textura *cuadricula = new Textura("cuadricula.jpg");
   agregar(new Material(cuadricula, 0.8, 0.8, 12, 140));

   agregar( new MallaDiscoP4() );
}

//-------------------------------------

// Practica 5
// Ejercicios adicionales

GrafoEsferasP5::GrafoEsferasP5() {

   const unsigned n_filas_esferas = 8,
               n_esferas_x_fila = 5 ;

   const float e = 0.4/n_esferas_x_fila ;
   int contador = 1;
   agregar( MAT_Escalado( e,e,e ));

   for( unsigned i = 0 ; i < n_filas_esferas ; i++ ){

      NodoGrafoEscena * fila_esferas = new NodoGrafoEscena() ;
      for( unsigned j = 0 ; j < n_esferas_x_fila ; j++ ){
         
         MallaInd * esfera = new Esfera(25,25) ;
         esfera->ponerIdentificador(contador);
         fila_esferas->agregar( MAT_Traslacion( {2.2, 0.0, 0.0} ));
         fila_esferas->agregar( esfera );

         contador++;

      }

      agregar( fila_esferas );
      agregar( MAT_Traslacion( {0.0, 0.0, 5.0} ));
   }
}

//-------------------------------------------
// Ejercicio adicional

GrafoEsferasP5_2::GrafoEsferasP5_2()
{
   const unsigned n_filas_esferas = 8, n_esferas_x_fila = 5;
   const float e = 2.5/n_esferas_x_fila;
   int contador = 1;
   agregar( MAT_Escalado( e, e, e ));  
   for( unsigned i = 0 ; i < n_filas_esferas ; i++ ){

      NodoGrafoEscena * fila_esferas = new NodoGrafoEscena();
      fila_esferas->agregar( MAT_Traslacion( {3.0, 0.0, 0.0} ));
      for( unsigned j = 0 ; j < n_esferas_x_fila ; j++ ){

         MallaInd * esfera = new Esfera(25, 25) ;
         esfera->ponerIdentificador(contador);
         fila_esferas->agregar( MAT_Traslacion( {2.5, 0.0, 0.0} ));
         fila_esferas->agregar( esfera );
         contador++;
      }
      agregar( fila_esferas );
      agregar( MAT_Rotacion( 360.0/n_filas_esferas, { 0.0, 1.0, 0.0 }));
   }
}



AndroidCabeza::AndroidCabeza(){
   
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));

      agregar(new ObjetoModificable({1, 2.5, 0}, 135, {1,0,0}, {0.1,0.1,0.1}, * new SemiEsfera(20,20, {0,0,0})));
      agregar(MAT_Traslacion({0, 2.2, 0}));
      agregar(MAT_Rotacion(180, {0,0,1}));
      agregar(new SemiEsfera(20, 20, {0, 1, 0}));

   rotacionCabeza = leerPtrMatriz(indice);
}

unsigned AndroidCabeza::leerNumParametros() const{
    
   return 1;
}

void AndroidCabeza::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:

         * rotacionCabeza = MAT_Rotacion(sin(tSec)*40, {0,1,0});
      break;
   
   default:
         * rotacionCabeza = MAT_Rotacion(sin(tSec)*40, {0,1,0});
      break;
   }

}
AndroidCuerpo::AndroidCuerpo(){
   
   //agregar(MAT_Traslacion({0, 0, 0}));
   agregar(MAT_Escalado(1, 2, 1));
   agregar(new Cilindro(20,20, {0, 1, 0}));

}

AndroidTubo::AndroidTubo(){

   agregar(new ObjetoModificable({0, 3, 0}, 180, {1,0,0}, {1,1,1}, * new SemiEsfera(20,20, {0,1,0})));
   agregar(new ObjetoModificable({0, 0, 0}, 0, {1,0,0}, {1,1,1}, * new SemiEsfera(20,20, {0,1,0})));
   agregar(MAT_Escalado(1,3,1));
   agregar(new Cilindro(20,20, {0, 1, 0}));

}

AndroidExtremidad::AndroidExtremidad(Tupla3f traslacion, Tupla3f escalado, int id){

   identificador = id;

   agregar(MAT_Traslacion(traslacion));
   agregar(MAT_Escalado(escalado[0], escalado[1], escalado[2]));

   agregar(MAT_Traslacion({0,2,0}));
   int indice = agregar(MAT_Rotacion((0.0), {0.0, 1.0, 0.0}));
   agregar(MAT_Traslacion({0,-2,0}));
   
   agregar(new AndroidTubo());

   rotacionExtremidad = leerPtrMatriz(indice);
}

unsigned AndroidExtremidad::leerNumParametros() const{
    
   return 1;
}

void AndroidExtremidad::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:

         if(identificador == 0){
            * rotacionExtremidad = MAT_Rotacion(sin(tSec)*40, {1,0,0});
         }
         if(identificador == 1){
            * rotacionExtremidad = MAT_Rotacion(-1*sin(tSec)*40, {1,0,0});
         }
         
      break;
   
   default:
         * rotacionExtremidad = MAT_Rotacion(sin(tSec)*40, {1,0,0});
         
      break;
   }

}

NodoAndroid::NodoAndroid(){
   
   cabeza = new AndroidCabeza();
   agregar(cabeza);

   cuerpo = new AndroidCuerpo();
   agregar(cuerpo);

   brazo1 = new AndroidExtremidad({-1.4,1,0}, {0.3, 0.3, 0.3}, 0);
   brazo2 = new AndroidExtremidad({1.4,1,0}, {0.3, 0.3, 0.3}, 1);
   agregar(brazo1);
   agregar(brazo2);

   pierna1 = new AndroidExtremidad({-0.5, -0.5,0}, {0.3, 0.3, 0.3}, 2);
   pierna2 = new AndroidExtremidad({0.5, -0.5,0}, {0.3, 0.3, 0.3}, 3);
   agregar(pierna1);
   agregar(pierna2);

}

unsigned NodoAndroid::leerNumParametros() const{
    
   return 1;
}

void NodoAndroid::actualizarEstadoParametro( const unsigned iParam, const float tSec )
{
   assert(iParam < leerNumParametros());
   
   switch (iParam)
   {
   case 0:

         brazo1->actualizarEstadoParametro(iParam, tSec);
         brazo2->actualizarEstadoParametro(iParam, tSec);
         cabeza->actualizarEstadoParametro(iParam, tSec);
      break;
   
   default:
         brazo1->actualizarEstadoParametro(iParam, tSec);
         brazo2->actualizarEstadoParametro(iParam, tSec);
         cabeza->actualizarEstadoParametro(iParam, tSec);
         
      break;
   }

}




