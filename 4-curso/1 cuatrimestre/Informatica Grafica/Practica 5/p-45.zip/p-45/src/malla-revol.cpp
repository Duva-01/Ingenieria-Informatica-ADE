// Nombre: David Apellidos: Martinez Diaz Titulación: GIADE.
// email: dmartinez01@correo.ugr.es DNI o pasaporte: 44669141J

// *********************************************************************
// **
// ** Informática Gráfica, curso 2019-20
// ** Implementación de la clase 'MallaRevol'
// **
// *********************************************************************

#include "ig-aux.h"
#include "lector-ply.h"
#include "malla-revol.h"

using namespace std ;

// *****************************************************************************


// Método que crea las tablas de vértices, triángulos, normales y cc.de.tt.
// a partir de un perfil y el número de copias que queremos de dicho perfil.
void MallaRevol::inicializar
(
   const std::vector<Tupla3f> & perfil,     // tabla de vértices del perfil original
   const unsigned               num_copias  // número de copias del perfil
)
{
   // COMPLETAR: Práctica 2: completar: creación de la malla....
   
   float x,y;

   vertices.clear();

   for(int i=0; i <= num_copias-1; i++){

      for(int j=0; j <= perfil.size()-1; j++){

         Tupla3f p = perfil.at(j);
         Tupla3f q;

         q = MAT_Rotacion(360*i/(num_copias-1), {0.0,1.0, 0.0})*p;
         vertices.push_back(q);
      }
   }

   // Añadimmos los triangulos

   triangulos.clear();

   float k;

   for(int i = 0; i <= num_copias - 2; i++){

      for(int j=0; j <= perfil.size() - 2; j++){

         k = i*perfil.size() + j;
         triangulos.push_back({k, k+perfil.size(), k+perfil.size()+1});
         triangulos.push_back({k, k+perfil.size()+1, k+1});

      }
   }

   // -------------------------------------------------------
   // Practica 4
   //------------------------------------------------------

   // COMPLETAR: Práctica 4: cálculo normales y coordenadas de textura

   //////////////////////////////////////////////////////////////////
   // Calculamos las normales de las aristas

   std::vector<Tupla3f> normales_m;

   for (unsigned int i = 0; i < perfil.size()-1; i++){
      float v_1 = (perfil[i+1] - perfil[i])(0);
      float v_2 = (perfil[i+1] - perfil[i])(1);
      Tupla3f m_i({v_2, -v_1, 0.0}); // giro de un vector -90º

      if (m_i.lengthSq() != 0) // por si hubiera dos puntos seguidos iguales
         m_i = m_i.normalized(); 

      normales_m.push_back(m_i);
   }

   // Calculamos las normales de los vertices
   std::vector<Tupla3f> normales_n;

   normales_n.push_back(normales_m[0]);
   for (unsigned int i = 1; i < perfil.size()-1; i++)
      normales_n.push_back( (normales_m[i-1] + normales_m[i]).normalized() );

   normales_n.push_back( normales_m[perfil.size()-2] );

   // Calculamos los vectores d y t, junto con sumas_parciales (vector auxiliar)
   std::vector<float> d;
   std::vector<float> t;
   std::vector<float> sumas_parciales;
   float suma_total;

   for (unsigned int i = 0; i < perfil.size()-1; i++)
      d.push_back( sqrt( (perfil[i+1] - perfil[i]).lengthSq() ) );

   sumas_parciales.push_back(0.0);
   for (unsigned int i = 1; i < perfil.size(); i++)
      sumas_parciales.push_back(sumas_parciales[i-1] + d[i-1]);

   suma_total = sumas_parciales[perfil.size()-1];
   t.push_back(0.0);
   for (unsigned int i = 1; i < perfil.size(); i++)
      t.push_back( sumas_parciales[i] / suma_total );
   //////////////////////////////////////////////////////////////////
   
   for(int i=0; i <= num_copias-1; i++){

      for(int j=0; j <= perfil.size()-1; j++){

         nor_ver.push_back( MAT_Rotacion(2.0*180.0*i / (num_copias-1), {0.0, 1.0, 0.0}) * normales_n[j] );
         cc_tt_ver.push_back({float(i) / (num_copias-1), 1-t[j]}); // i y j están cambiados
      }
   }
   
}

// -----------------------------------------------------------------------------
// constructor, a partir de un archivo PLY

MallaRevolPLY::MallaRevolPLY
(
   const std::string & nombre_arch,
   const unsigned      nperfiles
)
{
   ponerNombre( std::string("malla por revolución del perfil en '"+ nombre_arch + "'" ));
   // COMPLETAR: práctica 2: crear la malla de revolución
   // Leer los vértice del perfil desde un PLY, después llamar a 'inicializar'
   // ...........................

   std::vector<tup_mat::Tupla3f> aux;
   LeerVerticesPLY(nombre_arch, aux);
   inicializar(aux, nperfiles);

}

//------------------------

Cilindro::Cilindro(const int num_vert_per, const unsigned nperfiles, Tupla3f colores ){

   std::vector<Tupla3f> perfil;

   perfil.push_back({0.0, 0.0, 0.0});
   
   for(int i=0; i<num_vert_per; i++){
      perfil.push_back({1.0, (i*(1.0/(num_vert_per-1))), 0.0});
   }
   perfil.push_back({0.0, 1, 0.0});
   
   inicializar(perfil, nperfiles);

   for(int i=0; i<vertices.size(); i++){
      col_ver.push_back(colores);
   }
}

//--------------------------

Cono::Cono(const int num_vert_per, const unsigned nperfiles, float pendiente){

   // y = mx + b
   std::vector<Tupla3f> perfil;
   float incr_dist = 1.0/num_vert_per;
   float distancia = 0.0;
   
   perfil.push_back({0.0, 0.0, 0.0});

   for(int i=0; i<=num_vert_per; i++){
      
      perfil.push_back({1.0-distancia, pendiente*distancia, 0.0});
      distancia += incr_dist;
   }
   
   inicializar(perfil, nperfiles);
}

//-----------------------------

Esfera::Esfera(const int num_vert_per, const unsigned nperfiles ){

   std::vector<Tupla3f> perfil;
   float x,y;

   for(int angulo=-90; angulo<=90; angulo+=180/num_vert_per){

      x = cos( angulo*M_PI/180.0 );
      y = sin( angulo*M_PI/180.0 );
      perfil.push_back({x, y, 0.0});
   }

   
   inicializar(perfil, nperfiles);
}


SemiEsfera::SemiEsfera(const int num_vert_per, const unsigned nperfiles, Tupla3f colores ){

   std::vector<Tupla3f> perfil;
   float x,y;

   for(int angulo=-90; angulo<=0; angulo+=180/num_vert_per){

      x = cos( angulo*M_PI/180.0 );
      y = sin( angulo*M_PI/180.0 );

      perfil.push_back({x, y, 0.0});

   }

   perfil.push_back({0, 0, 0.0});

   inicializar(perfil, nperfiles);

   for(int i=0; i<vertices.size(); i++){
      col_ver.push_back(colores);
   }
}

//------------------------------


Aro::Aro(const int num_vert_per, const unsigned nperfiles, float radio_int, float radio_aro, float a, float b, float c){

   float X_picos, Y_picos;
   float angulo_incr = 360.0/(nperfiles);
   float angulo = 360.0/(nperfiles);

   std::vector<Tupla3f> perfil;

   for(int i=0; i<=nperfiles; i++){

      X_picos = radio_int + radio_aro*cos( angulo*M_PI/180 );
      Y_picos = radio_int + radio_aro*sin( angulo*M_PI/180 );

      //std::cout << "Agrego el punto en la posicion: " << X_picos << ", " << Y_picos << " con un angulo de " << angulo << std::endl;

      perfil.push_back({X_picos, Y_picos, 0.0});
   
      angulo += angulo_incr;
   }

   inicializar(perfil, nperfiles);

   for(int i=0; i<vertices.size(); i++){
      col_ver.push_back({a,b,c});
   }
}

// Posible ejercicio de examen

void MallaBarrido::inicializar
(
   const std::vector<Tupla3f> & perfil,     // tabla de vértices del perfil original
   const unsigned               num_copias  // número de copias del perfil
)
{
   // COMPLETAR: Práctica 2: completar: creación de la malla....
   Tupla3f q;
   float x,y;

   vertices.clear();

   float altura_sumar = 1.0/(num_copias-1);

   for(int i=0; i <= num_copias-1; i++){

      for(int j=0; j <= perfil.size()-1; j++){

         q = {perfil.at(j)(X), i*altura_sumar, perfil.at(j)(Z)};
         vertices.push_back(q);
      }
   }

   // Añadimmos los triangulos

   triangulos.clear();

   float k;

   for(int i = 0; i <= num_copias - 2; i++){

      for(int j=0; j <= perfil.size() - 2; j++){

         k = i*perfil.size() + j;
         triangulos.push_back({k, k+perfil.size(), k+perfil.size()+1});
         triangulos.push_back({k, k+perfil.size()+1, k+1});

      }
   }
}

SemiCilindro::SemiCilindro(const int num_vert_per, const unsigned nperfiles){

   std::vector<Tupla3f> perfil;
   float x,z;

   for(int angulo=-90; angulo<=90; angulo+=180/num_vert_per){

      x = cos( angulo*M_PI/180.0 );
      z = sin( angulo*M_PI/180.0 );
      perfil.push_back({x, 0.0, z});
   }

   inicializar(perfil, nperfiles);
}

/*
Otra manerra

   std::vector<Tupla3f> perfil;
   
      float radianes_rotacion = M_PI / (num_verts_per-1);
      for(int i=0; i<num_verts_per; i++){
         perfil.push_back({cos(i*radianes_rotacion ) ,0.0, sin(i*radianes_rotacion)}); //Para intentar ponerlos de arriba a abajo
      }

   inicializar(perfil, nperfiles);

*/


//-----------------------------
// 2 ejercicio del examen

CopaRevol::CopaRevol(const int num_verts_per,const unsigned nperfiles){

   std::vector<Tupla3f> perfil;
   float x,y;

   // Primera circunferencia

   for(int angulo=-90; angulo<=0; angulo+=180/num_verts_per){

      x = cos( angulo*M_PI/180.0 );
      y = 2+ sin( angulo*M_PI/180.0 );
      perfil.push_back({x, y, 0.0});
   }

    // Segunda circunferencia

   for(int angulo=180; angulo<=270; angulo+=180/num_verts_per){

      x = 1.2 + cos( angulo*M_PI/180.0 );
      y = 1.2 + sin( angulo*M_PI/180.0 );
      perfil.push_back({x, y, 0.0});
   }
   perfil.push_back({1.2, 0.0, 0.0});

   inicializar(perfil, nperfiles);
}