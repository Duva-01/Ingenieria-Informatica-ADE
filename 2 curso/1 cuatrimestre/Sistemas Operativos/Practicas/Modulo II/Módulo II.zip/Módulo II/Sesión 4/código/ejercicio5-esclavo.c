#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <math.h>

int esPrimo(int num);

int main(int argc, char* argv[]){
    char primo_c[20];

    if (argc != 3){
        printf("Sintaxis de ejecución: ejercicio5-esclavo <a> <b>\n");
        exit(EXIT_FAILURE);
    }
    
    int min = atoi(argv[1]), max = atoi(argv[2]);
    for (int candidato = min; candidato <= max; ++candidato)
        if (esPrimo(candidato))
            write(STDOUT_FILENO, &candidato, sizeof(int));

    return EXIT_SUCCESS;
}

int esPrimo(int num){
    char primo_c[10];
    for (int i = 2; i <= sqrt(num); ++i)
        if (num % i == 0)
            return 0;

    return 1;
}