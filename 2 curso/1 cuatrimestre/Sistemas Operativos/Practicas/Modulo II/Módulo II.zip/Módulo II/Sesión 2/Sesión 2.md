### SESIÓN 2 - MÓDULO II

____

##### <u>Ejercicio 1</u>: ¿Qué hace el siguiente programa? (Respuesta copiada del Portfolio Jesús García)

- Lo que hace el programa es crear un archivo llamado archivo1 con permisos de lectura, escritura y ejecución para el grupo, seguidamente pone la máscara a 0 con la orden umask(0) y después crea otro archivo llamado archivo2, con los mismos permisos que el archivo anterior.
- Luego comprueba que se puede acceder a los atributos del primer archivo con la orden stat.
- Después con chmod cambiamos los permisos del primer archivo haciendo un AND lógico del estado del archivo(accediendo al struct atributos) con el negado del permiso de ejecución para el grupo, con lo que le quitamos el permiso de ejecución para el grupo. También activamos la asignación del GID del propietario al GID efectivo del proceso que ejecute el archivo.
- Por último con chmod cambiamos los permisos del segundo archivo para que tenga todos los permisos para el propio usuario, permiso de lectura y escritura para el grupo, y lectura para el resto de usuarios.



##### <u>Ejercicio 2</u>: Realiza un programa en C utilizando las llamadas al sistema necesarias que acepte como entrada: - un argumento que representa el 'pathname' de un directorio - otro argumento que es un número octal de 4 dígitos (similar al que se puede utilizar para cambiar los permisos en la llamada al sistema chmod). Para convertir este argumento tipo cadena a un tipo numérico puedes utilizar la función strtol. Consulta el manual en línea para conocer sus argumentos.

```c
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>  // Biblioteca para utilizar el struct DIR y dirent
#include <dirent.h>     // Biblioteca con funciones para manejar directorios

int main(int argc, char *argv[]){
    DIR *dir;
    struct dirent *entrada;
    struct stat atributos;
    int permisosNuevos, permisosAntiguos;
    char path_entrada[512];

    if (argc != 3){
        printf("Sintaxis de ejecución: ./ejercicio2 <pathname> <número_octal>\n");
        exit(-1);
    }

    // Abrir directorio
    if ((dir = opendir(argv[1])) == NULL){
        printf("Error %d en la apertura del directorio\n", errno);
        perror("Error en opendir\n");
        exit(-1);
    }

    permisosNuevos = strtol(argv[2], NULL, 8);

    // Leer directorio
    while((entrada = readdir(dir)) != 0){
        sprintf(path_entrada, "%s/%s", argv[1], entrada->d_name);
        lstat(path_entrada, &atributos);
        permisosAntiguos = atributos.st_mode;

        if (strcmp(entrada->d_name, ".") && strcmp(entrada->d_name, "..")){
            if (chmod(path_entrada, permisosNuevos) == 0)
                printf("%s: %o %o\n", path_entrada, permisosAntiguos, permisosNuevos);
            else
                printf("%s: %d %o\n", path_entrada, errno, permisosAntiguos);
        }
    }

    // Cerrar directorio
    closedir(dir);

    return 0;
}
```



##### <u>Ejercicio 3</u>: Programa una nueva orden que recorra la jerarquía de subdirectorios existentes a partir de uno dado como argumento y devuelva la cuenta de todos aquellos archivos regulares que tengan permiso de ejecución para el grupo y para otros.

```c
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>  // Biblioteca para utilizar el struct DIR y dirent
#include <dirent.h>     // Biblioteca con funciones para manejar directorios

int regulares = 0;
long long tamano = 0;

void buscar(char* pathname);

int main(int argc, char *argv[]){
    char pathname[256];

    if (argc > 2){
        printf("Sintaxis: ./ejercicio3 pathname");
        exit(1);
    }
    else if (argc == 2) 
        strcpy(pathname, argv[1]);
    else 
        strcpy(pathname, ".");

    printf("Los i-nodos son:\n");
    buscar(pathname);
    printf("Existen %d archivos regulares con permiso x para grupo y otros\n", regulares);
    printf("El tamano total ocupado por dichos archivos es %lld bytes\n", tamano);

    return 0;
}

void buscar(char* pathname){
    DIR *dir;
    struct dirent *archivo;
    struct stat atributos;
    char path_archivo[512];

    dir = opendir(pathname);

    while((archivo = readdir(dir)) != 0){
        sprintf(path_archivo, "%s/%s", pathname, archivo->d_name);
        lstat(path_archivo, &atributos);
        
        if (strcmp(archivo->d_name, ".") && strcmp(archivo->d_name, "..")){
            if (S_ISREG(atributos.st_mode) && (atributos.st_mode & S_IXGRP) && (atributos.st_mode & S_IXOTH)){
                printf("%s %ld\n", path_archivo, archivo->d_ino);

                regulares += 1;
                tamano += atributos.st_size;
            }
            else if (S_ISDIR(atributos.st_mode))
               buscar(path_archivo); 
        }
    }
}
```



##### <u>Ejercicio 4</u>: Implementa de nuevo el programa buscar del ejercicio 3 utilizando la llamada al sistema nftw.
```c
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>  // Biblioteca para utilizar el struct DIR y dirent
#include <dirent.h>     // Biblioteca con funciones para manejar directorios
#include <ftw.h>        // Biblioteca para trabajar con nftw() 

int regulares = 0;
long long tamano = 0;

int visitar(const char* path, const struct stat* atributos, int flags, struct FTW* ftw){
    if (S_ISREG(atributos->st_mode) && (atributos->st_mode & S_IXGRP) && (atributos->st_mode & S_IXOTH)){
        printf("%s %ld\n", path, atributos->st_ino);

        regulares += 1;
        tamano += atributos->st_size;
    }
    
    return 0;
}

int main(int argc, char *argv[]){
    char pathname[256];

    if (argc > 2){
        printf("Sintaxis: ./ejercicio3 pathname");
        exit(1);
    }
    else if (argc == 2) 
        strcpy(pathname, argv[1]);
    else 
        strcpy(pathname, ".");

    printf("Los i-nodos son:\n");
    nftw(pathname, visitar, 10, 0);
    printf("Existen %d archivos regulares con permiso x para grupo y otros\n", regulares);
    printf("El tamano total ocupado por dichos archivos es %lld bytes\n", tamano);

    return 0; 
}
```

