#include <sys/types.h>
#include <limits.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>

void handler(int signum){
    // Se inicializa una sola vez y guarda valores a través de las llamadas a la función
    static int recuento[_NSIG] = {0};
    recuento[signum-1] += 1;
    printf("Recibida la señal %d, un total de %d veces\n", signum, recuento[signum-1]);
}

int main(){
    struct sigaction sa;
    
    sa.sa_handler = handler;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);

    printf("No puedo manejar las señales 9 (SIGKILL), 19 (SIGSTOP), 32 y 33\n");
    printf("Esperando la recepción de señales...\n");

    // Definimos el comportamiento para todas las señales (kill -l para listarlas) recorriendolas con un for
    for (int i = 1; i < _NSIG; ++i)
        if (sigaction(i, &sa, NULL) == -1)
            printf("Error al intentar establecer el manejador de la señal %d\n", i);

    while (1);
}