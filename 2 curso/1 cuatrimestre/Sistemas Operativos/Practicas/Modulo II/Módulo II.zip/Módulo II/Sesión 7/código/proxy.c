/**
 * @file proxy.c
 * @author Grupo 1: Isabel María Moreno Cuadrado, Inmaculada García, Ángel Olmedo, 
 * Juan Fernandez de Cañete, José Daniel Barranquero y Federico Cabrera.
 * @date January 2021
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char* argv[]){
    char buffer[1024];
    int fdb, fd_tmp;
    int leidos;
    FILE* tmp = tmpfile();

    // Transmitimos toda la entrada al fichero temporal
    fseek(tmp, 0, SEEK_SET);
    while (leidos = read(STDIN_FILENO, buffer, 1024) != 0)
        fwrite(buffer, sizeof(char), leidos-1, tmp);

    // Abrimos el archivo cerrojo y lo bloqueamos
    fdb = open("archivo_bloqueo", O_RDWR);
    flock(fdb, LOCK_EX);

    // Recuperamos del archivo temporal e imprimimos por la salida estándar
    fseek(tmp, 0, SEEK_SET);
    while(!feof(tmp)){
        fread(buffer, sizeof(char), 1024, tmp);

        write(STDOUT_FILENO, buffer, strlen(buffer)-1);
    }

    // Desbloqueamos el archivo de bloqueo
    flock(fdb, LOCK_UN);

    // Eliminamos nuestro FIFO antes de terminar
    char nombre_fifoProxy[1024];
    sprintf(nombre_fifoProxy, "fifo.%d", getpid());
    unlink(nombre_fifoProxy);

    exit(EXIT_SUCCESS);
}