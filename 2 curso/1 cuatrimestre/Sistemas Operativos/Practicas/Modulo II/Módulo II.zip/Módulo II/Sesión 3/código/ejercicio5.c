#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>

#define NUMHIJOS 5

int main(int argc, char *argv[]){
	int estado;
	int i, j, k;
	int buffer[NUMHIJOS];
	pid_t pid;
    
	if (setvbuf(stdout, NULL, _IONBF, 0) != 0){
		perror("\nError en setvbuf");
	}

	for (i = 0; i < NUMHIJOS; i++){
		if ((pid = fork()) < 0){
			perror("\nError en el fork");
			exit(-1);
		}
		if (pid == 0) break;
		buffer[i] = pid;
	}
    
	// Proceso hijo
	if (pid == 0){ 
		printf("\nSoy el hijo %d\n", getpid());
		exit(0);
	}

	// Proceso padre
	sleep(1);
	if (pid != 0){
		// Con k = 1 esperamos a los impares y después con k = 2 a los pares
		for(j = k = 1; j <= 2; ++j){
			for(; k <= NUMHIJOS; k += 2){
				pid_t childpid;

				// Con waitpid podemos especificar a qué proceso esperar
				// pid = waitpid(buffer[k], NULL, NULL);
				childpid = waitpid(buffer[k-1], &estado, NULL);

				printf("\nAcaba de finalizar mi hijo con PID %d y con estado %d\n", childpid, estado);
				printf("Sólo me quedan %d hijos vivos\n", i);
				i--;
			}
			k = 2;
		}
	}
	printf("\n");

	return 0;
}