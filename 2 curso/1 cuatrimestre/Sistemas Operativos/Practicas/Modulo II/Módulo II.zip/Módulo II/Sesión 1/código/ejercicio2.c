// Biblioteca para printf()
#include <stdio.h>
// Bibliotecas para trabajar con open()
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
// Biblioteca para trabajar con read() y con write(), y con las variables de I/O estándares
#include <unistd.h>
// Biblioteca para trabajar con la variable para manejar errores errno
#include <errno.h>
// Biblioteca para utilizar strlen()
#include <string.h>
// Biblioteca para poder utilizar exit()
#include <stdlib.h>

int main(int argc, char *argv[]){
	int filein, fileout;
	int cont = 0, leidos;
    char string[] = "El número de bloques es %d\n";
	char buff_1[80], buff_2[30];

	// int open(const char *pathname, int flags);
	// Required flags: O_RDONLY, O_WRONLY, or O_RDWR
	if (argc == 2){
        // Abrimos el archivo de entrada con permisos de solo lectura
		if ( (filein = open(argv[1], O_RDONLY)) < 0){
            printf("Error %d en apertura del fichero de entrada\n", errno);
            perror("Error en open\n");
            exit(-1);
        }
	}
	else if (argc == 1){
        // Nuestra variable para la entrada de datos estará asociada a la entrada estándar
		filein = STDIN_FILENO;
	}
    else{
        printf("Error en el número de argumentos\n");
        printf("Terminando programa...\n");
        exit(-1);
    }
    
    // Abrimos/Creamos el archivo de salida
	// O_TRUNC: If the file already exists and is a regular file and the open mode allows writing it will be truncated to length 0.
	// O_WRONLY: Request opening the file write-only
	// S_IRUSR: 00400 user has read permission 
	// S_IWUSR: 00200 user has write permission 
	if ( (fileout = open("salida.txt", O_CREAT|O_TRUNC|O_WRONLY, S_IRUSR|S_IWUSR)) < 0){
        printf("Error %d en apertura del fichero de salida\n", errno);
        perror("Error en open\n");
        exit(-1);
    }
    
    // Empezamos unos bytes más adelante para reservar espacio para imprimir después el mensaje del apartado 2
    lseek(fileout, strlen(string)-1, SEEK_SET);

    // Vamos leyendo de 80 en 80 los caracteres desde la entrada, almacenado en buff1
    // ssize_t read(int fd, void *buf, size_t count);
    while( (leidos = read(filein, buff_1, 80)) != 0){
        if (leidos == -1){
            printf("Error %d en la lectura del fichero de entrada\n", errno);
            perror("Error en read");
            exit(-1);
        }

		// Utilizamos sprintf para almacenar en buff_out nuestro mensaje informativo
		cont++;
		sprintf(buff_2, "\nBloque %d\n", cont);
		write (fileout, buff_2, strlen(buff_2));
		write (fileout, buff_1, leidos);
		write (fileout, "\n", 1);
	}
    
    // Segunda parte del ejercicio. Poner al principio el mensaje del número de bloques
    lseek(fileout, 0, SEEK_SET);
    sprintf(buff_2, string, cont);
    write(fileout, buff_2, strlen(buff_2));
    
    // Finalizamos el programa cerrando antes los ficheros abiertos
    if (close(fileout) == -1){
        printf("Error %d al cerrar el fichero de salida\n", errno);
        perror("Error en close\n");
        exit(-1);
    }

    if(close(filein) == -1){
        printf("Error %d al cerrar el fichero de entrada\n", errno);
        perror("Error en close\n");
        exit(-1);
    }
	
	return EXIT_SUCCESS;
}