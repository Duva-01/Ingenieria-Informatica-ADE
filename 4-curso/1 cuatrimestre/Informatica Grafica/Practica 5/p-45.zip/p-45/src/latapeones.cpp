// Nombre: David Apellidos: Martinez Diaz Titulación: GIADE.
// email: dmartinez01@correo.ugr.es DNI o pasaporte: 44669141J

#include "latapeones.h"
#include "malla-revol.h"

LataPeones::LataPeones(){

   ponerNombre("Lata - Peones");
   std::string nombreTextura;

   
   nombreTextura = "lata-coke.jpg";
   NodoLata * coca = new NodoLata(nombreTextura,0.8, 0.8, 12, 140);

   coca->ponerIdentificador(1);
   coca->ponerNombre("Cocacola");
   agregar(coca);

   agregar(MAT_Traslacion({-1,0,0}));
   nombreTextura = "lata-pepsi.jpg";
   NodoLata * pepsi = new NodoLata(nombreTextura,0.8, 0.8, 12, 140);

   pepsi->ponerIdentificador(2);
   pepsi->ponerNombre("Pepsi");
   agregar(pepsi);

   agregar(MAT_Traslacion({-1,0,0}));
   nombreTextura = "window-icon.jpg";
   NodoLata * lata_ugr = new NodoLata(nombreTextura,0.8, 0.8, 12, 140);

   lata_ugr->ponerIdentificador(3);
   lata_ugr->ponerNombre("lata_ugr");
   agregar(lata_ugr);

   agregar(MAT_Traslacion({-1,0,0}));

   nombreTextura = "";
   NodoPeon * peonMate=  new NodoPeon(nombreTextura, 0.2, 0.2, 0.2, 5);
   peonMate->ponerIdentificador(4);
   peonMate->ponerNombre("Peon Mate");
   agregar(peonMate);

   agregar(MAT_Traslacion({0,0,-3}));

   nombreTextura = "";
   NodoPeon * peonOscuro =  new NodoPeon(nombreTextura, 0.0, 0.0, 1, 5);
   peonOscuro->ponerIdentificador(5);
   peonOscuro->ponerNombre("Peon Oscuro");
   agregar(peonOscuro);

   agregar(MAT_Traslacion({0,0,6}));

   nombreTextura = "text-madera.jpg";

   NodoPeon * peonMadera = new NodoPeon(nombreTextura, 0.5, 0.8, 12, 140);
   peonMadera->ponerIdentificador(6);
   peonMadera->ponerNombre("Peon Madera");
   agregar( peonMadera );
   
}

NodoPeon::NodoPeon(std::string & nombre_textura, float p_k_amb, float p_k_dif, float p_k_pse, float p_exp_pse)
{


   Textura *textura;
   if( nombre_textura != ""){
        textura = new Textura(nombre_textura);
        agregar(new Material(textura, p_k_amb, p_k_dif, p_k_pse, p_exp_pse));
   }
   else {
        agregar(new Material(p_k_amb, p_k_dif, p_k_pse, p_exp_pse));
   }
   

   agregar(new MallaRevolPLY("peon.ply", 25));

}