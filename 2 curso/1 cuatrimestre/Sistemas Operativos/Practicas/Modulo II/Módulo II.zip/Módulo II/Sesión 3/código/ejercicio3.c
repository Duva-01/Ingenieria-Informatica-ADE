#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int iteracion = 0;

int main(){
    int childpid, nprocs = 20;

    printf("Jerarquía de procesos 1\n");
    printf("-----------------------\n");

    for (int i = 0; i < nprocs; ++i){
        iteracion += 1;
        if ((childpid = fork()) == -1){
            printf("Error en la creación de un proceso hijo: %s\n", strerror(errno));
            perror("Error en fork\n");
            exit(EXIT_FAILURE);
        }

        // El padre se va "destruyendo" y el hijo continua en el búcle creando hijos. 
        if (childpid != 0){
            printf("Mi PID es: %d, y mi PPID es: %d. Iteración %d\n", getpid(), getppid(), iteracion);
            break;
        }
    }

    // printf("\n\nJerarquía de procesos 2\n");
    // printf("-----------------------\n");

    // for (int i = 0; i < nprocs; ++i){
    //     iteracion += 1;
    //     if ((childpid = fork()) == -1){
    //         printf("Error en la creación de un proceso hijo: %s\n", strerror(errno));
    //         perror("Error en fork\n");
    //         exit(EXIT_FAILURE);
    //     }

    //     // El hijo se va "destruyendo" y el padre original continua en el búcle creando hijos. 
    //     if (childpid == 0){
    //         printf("Mi PID es: %d, y mi PPID es: %d. Iteración %d\n", getpid(), getppid(), iteracion);
    //         break;
    //     }
    // } 

    sleep(1);
    return EXIT_SUCCESS;
}