#!/bin/bash
#Con este script voy a calcular los tiempos dependiendo del número de threads.
#Esta versión es para atcgrid, pero se puede modificar para pc quitando srun y cambiando los threads.

export OMP_NUM_THREADS=1
for (( i = 100; i <= 40100; i += 1000 )); do
    srun -p ac ./pmv-OpenMP-a2 $i >> tiempos.dat
done

echo -e "\n" >> tiempos.dat
export OMP_NUM_THREADS=4
for (( i = 100; i <= 40100; i += 1000 )); do
    srun -p ac ./pmv-OpenMP-a2 $i >> tiempos.dat
done

echo -e "\n" >> tiempos.dat
export OMP_NUM_THREADS=8
for (( i = 100; i <= 40100; i += 1000 )); do
    srun -p ac ./pmv-OpenMP-a2 $i >> tiempos.dat
done

echo -e "\n" >> tiempos.dat
export OMP_NUM_THREADS=12
for (( i = 100; i <= 40100; i += 1000 )); do
    srun -p ac ./pmv-OpenMP-a2 $i >> tiempos.dat
done
