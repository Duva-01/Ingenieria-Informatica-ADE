#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main(int argc, char *argv[])
{
	// [minA, maxA], [minB, maxB]
	int minA, maxB;
	int maxA, minB;
	int fdE1[2], fdE2[2], fdM[2];
	pid_t PID1, PID2;
	int valor;

	if (argc != 3) {
		printf("Sintaxis de ejecucion: ./maestro <a> <b>\n");
		exit(-1);
	}

	minA = strtol(argv[1], NULL, 10);
	maxB = strtol(argv[2], NULL, 10);

	pipe(fdE1);
	pipe(fdE2);
	pipe(fdM);

	if ((PID1 = fork()) == 0) {
		// hijo 1 == esclavo 1
		close(fdE2[0]);
		close(fdE2[1]);
		close(fdE1[1]);
		close(fdM[0]);
		// E1 -> M

		// [0, 501] 
		dup2(fdE1[0], STDIN_FILENO);
		dup2(fdM[1], STDOUT_FILENO);

		execl("./esclavo", "esclavo", NULL);
	} else if ((PID2 = fork()) == 0) {
		// hijo 2 == esclavo 2
		close(fdE1[0]);
		close(fdE1[1]);
		close(fdE2[1]);
		close(fdM[0]);
		// E2 -> M

		// [501, 1000] 
		dup2(fdE2[0], STDIN_FILENO);
		dup2(fdM[1], STDOUT_FILENO);

		execl("./esclavo", "esclavo", NULL);
	} else {
		// padre
		close(fdE1[0]);
		close(fdE2[0]);

		maxA = (minA + maxB) / 2;
		minB = maxA + 1;

		// escritura del intervalo [minA, maxA] en el hijo 1 (esclavo 1)
		write(fdE1[1], &minA, sizeof(int));
		write(fdE1[1], &maxA, sizeof(int));

		// escritura del intervalo [minB, maxB] en el hijo 2 (esclavo 2)
		write(fdE2[1], &minB, sizeof(int));
		write(fdE2[1], &maxB, sizeof(int));

		while ((read(fdM[0], &valor, sizeof(int))) != 0) {
			printf("%d\n", valor);
		}
	}

	return 0;
}

