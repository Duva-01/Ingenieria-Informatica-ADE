// Módulo 3, Ejercicio 1. Realizado por Federico Cabrera, Ángel Olmedo, 
// Inma García, Juan Cañete e Isabel Moreno

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[]){
    int numero;
    pid_t pid;

    // Control de parámetros
    if (argc != 2){
        printf("Error en el número de argumentos\n");
        exit(-1);
    }
    
    numero = atoi(argv[1]);
    pid = fork();
    if (pid == -1){
        printf("Error en la creación de un proceso hijo\n");
        exit(-1);
    }
    
    printf("Mi PID es: %d, y mi PPID es: %d\n", getpid(), getppid());

    // Tareas para el proceso hijo
    if (pid == 0){
        printf("\n-> Estas instrucciones están siendo ejecutadas solo por el hijo\n");

        if (numero % 2 == 0)
            printf("\nEl número introducido %d es par\n", numero);
        else
            printf("\nEl número introducido %d es impar\n", numero);
    }
 
    // Tareas para el proceso padre
    if (pid != 0){
        printf("\n-> Estas instrucciones solo serán ejecutadas por el padre\n");

        if (numero % 4 == 0)
            printf("\nEl número introducido %d múltiplo de 4\n", numero);
        else
            printf("\nEl número introducido %d no es múltiplo de 4\n", numero);
    }
   
    return EXIT_SUCCESS;
}
