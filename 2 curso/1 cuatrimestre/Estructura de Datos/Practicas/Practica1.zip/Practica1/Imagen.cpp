/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 /*
  * File:   Imagen.cpp
  * Author: dmartinez01
  *
  * Created on 24 de octubre de 2020, 11:07
  */

#include "Imagen.h"

using namespace std;


/****************************************************************************/

Imagen::Imagen(int filas_aux, int cols_aux) {

    // Crear una imagen plana con valor 255 (blanco)
    filas = filas_aux;
    cols = cols_aux;

    img = new byte * [filas];

    for (int f = 0; f < filas; f++) {

        img[f] = new byte[cols];
        for (int c = 0; c < cols; c++) {
            img[f][c] = 255;
        }
    }


    // Crear el marco que delimita la imagen
    for (int f = 0; f < filas; f++) // lado izquierdo
        img[f][0] = 0;

    for (int f = 0; f < filas; f++) // lado derecho
        img[f][cols - 1] = 0;

    for (int c = 0; c < cols; c++) // lado superior
        img[0][c] = 0;

    for (int c = 0; c < cols; c++) // lado inferior
        img[filas - 1][c] = 0;


}

/****************************************************************************/

Imagen::~Imagen() {

    for (int f = 0; f < filas; f++)
        delete img[f];

    delete [] img;

};

/****************************************************************************/

int Imagen::num_filas() const {

    return filas;
}

/****************************************************************************/

int Imagen::num_columnas() const {

    return cols;
}

/****************************************************************************/

int & Imagen::Getcolumnas(){

    return cols;
}

/****************************************************************************/

int & Imagen::Getfilas(){

    return filas;
}

/****************************************************************************/


const unsigned char* Imagen::GetVector(){

    unsigned char* vector;
    vector = new unsigned char[filas * cols];

    for (int f = 0; f < filas; f++) {

        for (int c = 0; c < cols; c++) {

            vector[((f*cols) + c )] = valor_pixel(f, c);
        }

    }

    return vector;
}

void Imagen::CambiaPuntero(unsigned char* vector){

    if(img != nullptr){    
        delete []img;
    }
    
    img = new byte* [filas];
    for(int f=0; f<filas; f++){
        
        img[f] = new byte [cols];
        for(int c=0; c<cols; c++){
    
            img[f][c]=vector[(f*cols) + c];
        }
        
    }
    
}

/****************************************************************************/

byte Imagen::valor_pixel(int fila, int col) const {

    return img[fila][col];
}

/****************************************************************************/

void Imagen::enmarca_imagen()
{
    for (int f = 0; f < filas; f++) // lado izquierdo
        img[f][0] = 0;

    for (int f = 0; f < filas; f++) // lado derecho
        img[f][cols - 1] = 0;

    for (int c = 0; c < cols; c++) // lado superior
        img[0][c] = 0;

    for (int c = 0; c < cols; c++) // lado inferior
        img[filas - 1][c] = 0;

}

/****************************************************************************/

void Imagen::asigna_pixel(int fila, int col, byte valor) {

    img[fila][col] = valor;
}

/****************************************************************************/

byte Imagen::MaxMinImagen(bool opcion) {
    
    byte valor = 0;
    
    if (opcion) {

        for (int f = 0; f < num_filas(); f++)
        {
            for (int c = 0; c < num_columnas(); c++)
            {
                if (valor < valor_pixel(f, c)) {
                    valor = valor_pixel(f, c);
                }
            }
        }
    }

    else {

        valor = 1000;

        for (int f = 0; f < num_filas(); f++)
        {
            for (int c = 0; c < num_columnas(); c++)
            {
                if (valor > valor_pixel(f, c)) {
                    valor = valor_pixel(f, c);
                }
            }
        }
    }

    return valor;
}

/****************************************************************************/

TipoImagen Imagen::LeerTipo(ifstream& f){
  char c1,c2;
  TipoImagen res= IMG_DESCONOCIDO;

  if (f){
    c1=f.get();
    c2=f.get();
    if (f && c1=='P')
      switch (c2) {
        case '5': res= IMG_PGM; break;
        case '6': res= IMG_PPM; break;
        default: res= IMG_DESCONOCIDO;
      }
  }
  return res;
}

// _____________________________________________________________________________

TipoImagen Imagen::LeerTipoImagen(const char *nombre){
  ifstream f(nombre);
  return LeerTipo(f);
}


// _____________________________________________________________________________

char Imagen::SaltarSeparadores (ifstream& f){
  char c;
  do{
    c= f.get();
  } while (isspace(c));
  f.putback(c);
  return c;
}

// _____________________________________________________________________________

bool Imagen::LeerCabecera (ifstream& f, int& fils, int& cols){
    int maxvalor;
    string linea;
    while (SaltarSeparadores(f)=='#')
      getline(f,linea);

    f >> cols >> fils >> maxvalor;
    
    if (/*str &&*/ f && fils>0 && fils<5000 && cols>0 && cols<5000){
        f.get(); // Saltamos separador
        return true;
    }
    else 
      return false;
}



// _____________________________________________________________________________

unsigned char *Imagen::LeerImagenPPM (const char *nombre, int& fils, int& cols){
  unsigned char *res=0;
  fils=0;
  cols=0;
  ifstream f(nombre);
  
  if (LeerTipo(f)==IMG_PPM){
    if (LeerCabecera (f, fils, cols)){
        res= new unsigned char[fils*cols*3];
        f.read(reinterpret_cast<char *>(res),fils*cols*3);
        if (!f){
          delete[] res;
          res= 0;
        }
    }
  }
  return res;
}

// _____________________________________________________________________________

unsigned char *Imagen::LeerImagenPGM (const char *nombre, int& fils, int& cols){
  unsigned char *res=0;
  fils=0;
  cols=0;
  ifstream f(nombre);
  
  if (LeerTipo(f)==IMG_PGM){
    if (LeerCabecera (f, fils, cols)){
      res= new unsigned char[fils*cols];
      f.read(reinterpret_cast<char *>(res),fils*cols);
      if (!f){
        delete[] res;
        res= 0;
      }
    }
  }
  return res;
}

// _____________________________________________________________________________

bool Imagen::EscribirImagenPPM (const char *nombre, const unsigned char *datos, 
                        const int fils, const int cols){
  ofstream f(nombre);
  bool res= true;
  
  if (f){
    f << "P6" << endl;
    f << cols << ' ' << fils << endl;
    f << 255 << endl;
    f.write(reinterpret_cast<const char *>(datos),fils*cols*3);
    if (!f)
      res=false;
  }
  return res;
}
// _____________________________________________________________________________

bool Imagen::EscribirImagenPGM (const char *nombre, const unsigned char *datos, 
                        const int fils, const int cols){
  ofstream f(nombre);
  bool res= true;
  
  if (f){
    f << "P5" << endl;
    f << cols << ' ' << fils << endl;
    f << 255 << endl;
    f.write(reinterpret_cast<const char *>(datos),fils*cols);
    if (!f)
      res=false;
  }
  return res;
}


/**************************************/

void UmbralizarGrises(const char* fichero1, const char* fichero2, int T_1, int T_2) {

    Imagen fch1 (0,0);
   
    fch1.CambiaPuntero(fch1.LeerImagenPGM(fichero1, fch1.Getfilas(), fch1.Getcolumnas()));

    Imagen fch2(fch1.num_filas(), fch1.num_columnas());

    for (int f = 0; f < fch1.num_filas(); f++) {

        for (int c=0;c<fch1.Getcolumnas();c++)
        {
            if ( (fch1.valor_pixel(f,c) > T_1) && (fch1.valor_pixel(f, c) < T_2))
            {
                fch2.asigna_pixel(f, c, fch1.valor_pixel(f, c));
            
            }
            else {
                fch2.asigna_pixel(f, c, 255);
            }
        
        }
    }

    fch2.EscribirImagenPGM(fichero2, fch2.GetVector(), fch2.num_filas(), fch2.num_columnas());

}

void ZoomImagen(const char* fichero1, const char* fichero2, int x1, int y1, int x2, int y2) {

    int cont_f=y1, cont_c=x1;

    Imagen fch1(0, 0);
    
    fch1.CambiaPuntero(fch1.LeerImagenPGM(fichero1,fch1.Getfilas(),fch1.Getcolumnas()));

    Imagen fch2(((y2 - y1) * 2) - 1, ((x2 - x1) * 2) - 1);

    for (int f = 0; f < fch2.num_filas(); f++) {

        for (int c = 0;c < fch2.num_columnas();c++) {
            
            if (f%2 == 0 && c%2 == 0)
            {
                fch2.asigna_pixel(f, c, fch1.valor_pixel(cont_f, cont_c));
                cont_c++;
            }
            else {
                fch2.asigna_pixel(f, c, 0);
            }

        }
        if (f%2 == 0)
        {
            cont_f++;
        }
        
        cont_c = x1;
    }

    for (int f=0;f<fch2.num_filas();f=f+2)
    {
        for (int c = 0;c < fch2.Getcolumnas();c++)
        {
            if (fch2.valor_pixel(f, c) == 0)
            {
                fch2.asigna_pixel(f, c, (fch2.valor_pixel(f, c - 1) + fch2.valor_pixel(f, c + 1)) / 2);
            }
            
        }
    }

    for (int f = 1;f<fch2.num_filas();f=f+2)
    {
        for (int c = 0;c < fch2.Getcolumnas();c++)
        {
            if (f % 2 != 0)
            {
                fch2.asigna_pixel(f, c, (fch2.valor_pixel(f + 1, c) + fch2.valor_pixel(f - 1, c)) / 2);
            }
          
        }
    }

     fch2.EscribirImagenPGM(fichero2, fch2.GetVector(), fch2.num_filas(), fch2.num_columnas());
}

void AumentoContraste(const char* fichero1, const char* fichero2, int min, int max)
{
    
    Imagen fch1(0, 0);
    fch1.CambiaPuntero(fch1.LeerImagenPGM(fichero1, fch1.Getfilas(), fch1.Getcolumnas()));
    Imagen fch2(fch1.num_filas() ,fch1.num_columnas());
    
    unsigned char valor;

    const double max_img = fch1.MaxMinImagen(true);
    const double min_img = fch1.MaxMinImagen(false);
    const double valor_fijo = ((max - min) / (max_img-min_img));
    double valor_total = 0, decimales;
    int aux;


    for (int f = 0; f < fch2.num_filas(); f++)
    {
        for (int c = 0; c < fch2.num_columnas(); c++)
        {
            valor_total = min + (valor_fijo * (fch1.valor_pixel(f, c) - min_img));

            aux = valor_total;
            decimales = valor_total - aux;
            
            
            if (decimales >= 0.5)
            {
                valor = valor_total+1;
                fch2.asigna_pixel(f, c, valor);
            
            }
            else
            {
                valor = valor_total;
                fch2.asigna_pixel(f, c, valor);
            
            }
        }
    }

    fch2.EscribirImagenPGM(fichero2, fch2.GetVector(), fch2.num_filas(), fch2.num_columnas());

}

void Morphing(const char* fichero1, const char* fichero2, const char* fichero_final){
    
    
    Imagen fch2(0, 0);
    fch2.CambiaPuntero(fch2.LeerImagenPGM(fichero2, fch2.Getfilas(), fch2.Getcolumnas()));
    Imagen Intermedio(0,0);
    Intermedio.CambiaPuntero(Intermedio.LeerImagenPGM(fichero1, Intermedio.Getfilas(), Intermedio.Getcolumnas()));
    
    bool hay_variacion = true;
    byte valor;
    assert(( Intermedio.num_filas() == fch2.num_filas()) && (Intermedio.num_columnas() == fch2.num_columnas()));
    
    string direccion;
    string aux(fichero_final);
    
    for(int n=1; hay_variacion; n++){
          
        hay_variacion = false;
        for(int f=0; (f < Intermedio.num_filas()); f++){
            
            for (int c=0; c < Intermedio.num_columnas(); c++){
                
                if(Intermedio.valor_pixel(f, c) > fch2.valor_pixel(f, c)){
                    
                    valor = Intermedio.valor_pixel(f, c) - 1;
                    Intermedio.asigna_pixel(f, c, valor);
                    hay_variacion = true;
                }
                
                else if (Intermedio.valor_pixel(f, c) < fch2.valor_pixel(f, c)){
                    
                    valor = Intermedio.valor_pixel(f, c) + 1;
                    Intermedio.asigna_pixel(f, c, valor);
                    hay_variacion = true;
                }
                
            }
            
        }
        
        if(hay_variacion){
            
            direccion = aux + "/foto_" + to_string(n);
            Intermedio.EscribirImagenPGM(direccion.c_str(), Intermedio.GetVector(), Intermedio.num_filas(), Intermedio.num_columnas());   
          
        }
       
     }

}