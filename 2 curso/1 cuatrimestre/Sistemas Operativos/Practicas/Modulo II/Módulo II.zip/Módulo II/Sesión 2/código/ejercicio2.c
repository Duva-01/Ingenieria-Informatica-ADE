#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>  // Biblioteca para utilizar el struct DIR y dirent
#include <dirent.h>     // Biblioteca con funciones para manejar directorios

int main(int argc, char *argv[]){
    DIR *dir;
    struct dirent *entrada;
    struct stat atributos;
    int permisosNuevos, permisosAntiguos;
    char path_entrada[512];

    if (argc != 3){
        printf("Sintaxis de ejecución: ./ejercicio2 <pathname> <número_octal>\n");
        exit(-1);
    }

    // Abrir directorio
    if ((dir = opendir(argv[1])) == NULL){
        printf("Error %d en la apertura del directorio\n", errno);
        perror("Error en opendir\n");
        exit(-1);
    }

    permisosNuevos = strtol(argv[2], NULL, 8);

    // Leer directorio
    while((entrada = readdir(dir)) != 0){
        sprintf(path_entrada, "%s/%s", argv[1], entrada->d_name);
        lstat(path_entrada, &atributos);
        permisosAntiguos = atributos.st_mode;

        if (strcmp(entrada->d_name, ".") && strcmp(entrada->d_name, "..")){
            if (chmod(path_entrada, permisosNuevos) == 0)
                printf("%s: %o %o\n", path_entrada, permisosAntiguos, permisosNuevos);
            else
                printf("%s: %d %o\n", path_entrada, errno, permisosAntiguos);
        }
    }

    // Cerrar directorio
    closedir(dir);

    return 0;
}