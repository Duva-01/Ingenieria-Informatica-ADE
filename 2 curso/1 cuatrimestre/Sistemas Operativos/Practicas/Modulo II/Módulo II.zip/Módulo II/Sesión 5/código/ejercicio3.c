#include <stdio.h>
#include <signal.h>

int main(){
    sigset_t new_mask;

    // Inicializar la nueva mascara de señales a todas las señales
    // {SIGHUP, SIGINT, ..., SIGRTMAX}
    sigfillset(&new_mask); 

    // Eliminamos SIGUSR1 de la máscara
    // {SIGHUP, SIGINT, ..., SIGKILL, SIGSEGV, ..., SIGRTMAX}
    sigdelset(&new_mask, SIGUSR1); 

    // Esperar solo a SIGUSR1
    sigsuspend(&new_mask);

    return 0;
}