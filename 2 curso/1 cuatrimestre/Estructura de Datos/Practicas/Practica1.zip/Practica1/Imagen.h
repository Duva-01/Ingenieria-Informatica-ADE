/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 /*
  * File:   Imagen.h
  * Author: dmartinez01
  *
  * Created on 24 de octubre de 2020, 11:07
  */

#ifndef IMAGEN_H
#define IMAGEN_H

#include <iostream>

#include <string>
#include <fstream>
#include <istream>
#include <sstream>
#include <cassert>

using namespace std;
  /****************************************************************************/
  // Fichero: imagen.h
  // Fichero de cabecera asociado a la biblioteca libimg.a.
  // Implementacion del TDA imagen (imagen digital en niveles de gris).
  /****************************************************************************/

typedef unsigned char byte; // tipo base de cada pixel

 /**
      * @brief Tipo de imagen
      *
      * Declara una serie de constantes para representar los distintos tipos
      * de imágenes que se pueden manejar.
      *
      * @see LeerTipoImagen
      */
enum TipoImagen { IMG_DESCONOCIDO, IMG_PGM, IMG_PPM };
    
class Imagen {

private:

    int filas; // Número de filas de la imagen
    int cols; // Número de columnas de la imagen
    byte** img; // La imagen en si: una matriz dinamica 2D de bytes

public:


   
    /****************************************************************************/

    /**
        @brief Crear una imagen en memoria con "filas" filas y "cols" columnas.
               Reserva memoria para alojar la imagen de "filas" x "cols" pixeles.
               Recibe: int filas, Número de filas de la imagen.

        @param int cols, Número de columnas de la imagen.
        @param int filas, Número de filas de la imagen.
    */

    Imagen(int filas, int cols);

    /*****************************************************************************/
    /****************************************************************************/

    /**
        @brief Destructor, libera los recursos ocupados por la imagen.
               Devuelve: void.
    */

    ~Imagen();

    /****************************************************************************/
    /****************************************************************************/

    /**
        @brief Calcular el numero de filas de la imagen.
               Devuelve: int, Número de filas de la imagen.
    */

    int num_filas() const;

    /****************************************************************************/
    /****************************************************************************/

    /**
        @brief Calcular el numero de columnas de la imagen.
               Devuelve: int, Número de columnas de la imagen.
    */

    int num_columnas() const;

    /****************************************************************************/

    /**
        @brief Asignar el valor "valor" al pixel ("fila", "col") de la imagen.

        // Precondiciones:
        // 1. 0 <= "fila" < i.num_filas()
        // 2. 0 <= "col" < i.num_columnas()
        // 3. 0 <= valor <= 255

        @param int cols, Número de columnas de la imagen.
        @param int fila, Número de filas de la imagen.
        @param byte valor, valor a escribir.

        // Postcondiciones:
        // 1. "i"("fil","col") == "valor".
        // 2. Los restantes píxeles no se modifican.

    */

    void asigna_pixel(int fila, int col, byte valor);

    /****************************************************************************/

     /**
        @brief Recubre la matriz con un marco negro.
     */

    void enmarca_imagen();

    /**
       @brief Devuelve el numero de columnas por referencia
       @return devuelve el numero de columnas

    */

    int & Getcolumnas();

    /**
       @brief Devuelve el numero de filas por referencia
       @return devuelve el numero de filas

    */

    int & Getfilas();

    /**
       @brief Calcular el numero de filas de la imagen.
              Devuelve: int, Número de filas de la imagen.
       @return Puntero a la zona de memoria con los valores de los píxeles. 0 en caso de
       errores.
    */

    const unsigned char* GetVector();

    /**
       @brief Calcula el maximo/imagen valor de imagen.
       @param bool opcion, depende de su estado coge el maximo o el minimo.    
       @return  el valor maximo/minimo.
    */
    byte MaxMinImagen(bool opcion);

    
    /**
       @brief Esta funcion, limpia el puntero de la i magen, y le asigna 
     * los valores dados por el vector pasado por parametro.
       @param unsigned char* vector, puntero con los valores nuevos para la Imagen.    
       @return  no devuelve nada, es un void.
    */
    void CambiaPuntero(unsigned char* vector);
    /****************************************************************************/

    /**
        @brief Consultar el valor de la casilla ("fila", "col") de la imagen.

        // Precondiciones:
        // 1. 0 <= "fila" < i.num_filas ()
        // 2. 0 <= "col" < i.num_columnas ()

        @param int col, Número de columnas de la imagen.
        @param int fila, Número de filas de la imagen.

        // Devuelve: byte, valor de "i"("fila","col").
    */

    byte valor_pixel(int fila, int col) const;

    

/*****************************************************************************************************/

    
    /**
     *@brief es una funcion para obetener el tipo imagen de la imagen con la que 
     *estamos trabajando (Desconocido, PGM, PPM)
     *@param ifstream f, flujo de entreda del fichero al progranma
     *@return devuelve un TipoImagen
    */
    TipoImagen LeerTipo(ifstream & f);

    /**
    *@brief esta funcion nos quita los separadores al leer los archivos
    *@param ifstream f, felujo de entrada de fichero al programa
    *@return char
    */
    char SaltarSeparadores(ifstream & f);


    /**
    *@brief lee la cabecerea de un archivo 
    *@param ifstream f, flujo de entrada al fichero
    *@param int fils, fila de la clase imagen
    *@param int cols, columnas de la clase imagen
    *@return bool
    */
    bool LeerCabecera(ifstream & f, int& fils, int& cols);


/**
  * @brief Devuelve el tipo de imagen del archivo
  *
  * @param nombre indica el archivo de disco que consultar
  * @return Devuelve el tipo de la imagen en el archivo
  *
  * @see TipoImagen
  */
TipoImagen LeerTipoImagen (const char *nombre);

/**
  * @brief Lee una imagen de tipo PPM
  *
  * @param nombre archivo a leer
  * @param filas Parámetro de salida con las filas de la imagen.
  * @param columnas Parámetro de salida con las columnas de la imagen.
  * @return puntero a una nueva zona de memoria que contiene @a filas x @a columnas x 3
  * bytes que corresponden a los colores de todos los píxeles en formato
  * RGB (desde la esquina superior izqda a la inferior drcha). En caso de que no
  * no se pueda leer, se devuelve cero. (0).
  * @post En caso de éxito, el puntero apunta a una zona de memoria reservada en
  * memoria dinámica. Será el usuario el responsable de liberarla.
  */
unsigned char *LeerImagenPPM (const char *nombre, int& fils, int& cols);

/**
  * @brief Escribe una imagen de tipo PPM
  *
  * @param nombre archivo a escribir
  * @param datos punteros a los @a f x @a c x 3 bytes que corresponden a los valores
  *    de los píxeles de la imagen en formato RGB.
  * @param f filas de la imagen
  * @param c columnas de la imagen
  * @return si ha tenido éxito en la escritura.
  */
bool EscribirImagenPPM (const char *nombre, const unsigned char *datos, 
                        const int fils, const int cols);

/**
  * @brief Lee una imagen de tipo PGM
  *
  * @param nombre archivo a leer
  * @param filas Parámetro de salida con las filas de la imagen.
  * @param columnas Parámetro de salida con las columnas de la imagen.
  * @return puntero a una nueva zona de memoria que contiene @a filas x @a columnas
  * bytes que corresponden a los grises de todos los píxeles
  * (desde la esquina superior izqda a la inferior drcha). En caso de que no
  * no se pueda leer, se devuelve cero. (0).
  * @post En caso de éxito, el puntero apunta a una zona de memoria reservada en
  * memoria dinámica. Será el usuario el responsable de liberarla.
  */
unsigned char *LeerImagenPGM (const char *nombre, int& fils, int& cols);

/**
  * @brief Escribe una imagen de tipo PGM
  *
  * @param nombre archivo a escribir
  * @param datos punteros a los @a f x @a c bytes que corresponden a los valores
  *    de los píxeles de la imagen de grises.
  * @param f filas de la imagen
  * @param c columnas de la imagen
  * @return si ha tenido éxito en la escritura.
  */
bool EscribirImagenPGM (const char *nombre, const unsigned char *datos, 
                        const int fils, const int cols);


};

    /**
     @brief Consiste en generar a partir de una imagen original, otra imagen con el criterio de que si un
            pixel de la imagen original tiene un nivel de gris p comprendido en un intervalo
            definido por 2 umbrales T_1 y T_2.
     @param  fichero1: nombre del fichero que contiene la imagen original
     @param  fichero2:  nombre del fichero que contedrá el resultado de la transformación
     @param  T_1:   los valores del intervalo de la umbralización
     @param  T_2:   los valores del intervalo de la umbralización
     @return devuelve el fichero con la imagen umbralizada
    */
    void UmbralizarGrises(const char* fichero1, const char* fichero2, int T_1, int T_2);

    /**
     @brief  Consiste en realizar un zoom de una porción de la imagen mediante un simple procedimiento
             de interpolación consistente en construir a partir de una subimagen N x N, una imagen
             dedimension (2N-1) x (2N-1).
     @param  fichero1: nombre del fichero que contiene la imagen original
     @param  fichero2:  nombre del fichero que contedrá el resultado de la transformación
     @param  x1/y1:   coordenadas esquina superior izquierda.
     @param x2/y2:   coordenadas esquina inferior derecha.

    */
    void ZoomImagen(const char* fichero1, const char* fichero2, int x1, int y1, int x2, int y2);

    
    
     /**
     @brief  Consiste en cambiar los niveles maximos y minimos de grises de una imagen a 
             traves de una formula dada
     @param  nombre del fichero de imagen origen
     @param  nombre del fichero de imagen final con el filtro ya aplicado
     @param  minimo del intervalo
     @param  maximo del intervalo

    */
    void AumentoContraste(const char* fichero1, const char* fichero2,int min, int max);

    
    /**
     @brief  Este metodo, consiste en ir transicionando de una imagen origen a otra, 
     * cambiando los valores del puntero 1 a 1, asi creando un efecto de transicion
     @param  fichero1, nombre del fichero de imagen origen
     @param  fichero2, nombre del fichero de imagen final con el filtro ya aplicado
     @param  fichero_final, nombre del luegar donde se van a guardar las fotos hacia la transicion.
    */
    void Morphing(const char* fichero1, const char* fichero2, const char* fichero_final);

#endif /* IMAGEN_H */
