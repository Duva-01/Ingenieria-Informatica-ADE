#ifndef LATAPEONES_H
#define LATAPEONES_H

#include "grafo-escena.h"
#include "ig-aux.h"
#include "malla-ind.h"   // declaración de 'ContextoVis'
#include "lector-ply.h"
#include <string.h>
#include "malla-revol.h"

class LataPeones : public NodoGrafoEscena
{ 
    public:
        
        LataPeones() ; // constructor
} ;

class NodoPeon : public NodoGrafoEscena
{ public:

   NodoPeon(std::string & nombre_textura, float p_k_amb, float p_k_dif, float p_k_pse, float p_exp_pse) ; // constructor
} ;

#endif // LATAPEONES_H