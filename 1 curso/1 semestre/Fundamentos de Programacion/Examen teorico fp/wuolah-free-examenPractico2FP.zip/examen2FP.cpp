//Examen Parcial 2 FP Jos� Manuel Herrera Vera B2 75912813W

/*
Realizar un programa que lea una matriz de enteros y muestre ordenados (de forma creciente),
los elementos de la fila que contiene el mayor elemento de la matriz.
*/

#include<iostream>

using namespace std;

int main(){
	
	const int MAX = 50;
	int matriz[MAX][MAX];
	int vectorFila[MAX];
	int fila, columna, filaElemento, valor, elementoMayor;
	bool primerValor = true;
	
	//Pregunto por el numero de filas de la matriz
	do{
		cout << "Introduce el numero de filas que va a tener la matriz: " << endl;
		cin >> fila;
	}while(fila>MAX);
	
	//Pregunto por el numero de columnas de la matriz
	do{
		cout << "Introduce el numero de columnas que va a tener la matriz: " << endl;
		cin >> columna;
	}while(columna>MAX);
	
	//Introduzco los valores a la matriz a la vez que encuentro el mayor valor de la matriz y la fila en la que se encuentra
	for(int i = 0; i < fila; i++){
		for(int j = 0; j < columna; j++){
			cout << "Introduce el valor de la coordenada: (" << i << "," << j << ")" << endl;
			cin >> valor;
			matriz[i][j] = valor;
			
			if(primerValor){
				elementoMayor = valor;
				primerValor=false;
			}
			else if(valor > elementoMayor){
				elementoMayor = valor;
				filaElemento = i;
			}
			
		}
	}
	
	//Aqui copio la fila que contiene al elemento mayor de la matriz
	for(int i = 0; i < columna; i++){
		vectorFila[i] = matriz [filaElemento][i];
	}
	
	//Aplico el Algoritmo de ordenacion Burbuja
	int temp = 0;
	
	for(int i = 1; i < columna; i++){
		for(int j = 0; j < columna - 1; j++){
			if(vectorFila[j] > vectorFila[j+1]){
				temp = vectorFila[j];
				vectorFila[j] = vectorFila[j+1];
				vectorFila[j+1] = temp;
			}
		}
	}
	
	//Imprimo la fila ordenada de forma creciente donde se encontraba el mayor valor de la matriz 
	cout << "Vector resultante: " << endl;	
	for(int i = 0; i < columna; i++){
		cout << vectorFila[i] << " " ;
	}
}
