/**
 * @file figura1-Modificado1.c
 * @author Daniel Pérez Ruiz
 * @brief Implementacion del codigo de la figura1 MODIFICADO (Version 1)
 *
 * MODIFICACION REALIZADA: MODIFICACION DE STRUCT
 * Compilacion: gcc -O2 figura1-Modificado1.c -o figura1-Modificado1
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//STRUCT ORIGINAL
/* struct {
    int a;
    int b;
} s[5000]; */


/**
 * @brief Struct de la figura1 implementado
 */
 struct {
   int a[5000];
   int b[5000];
 } s;

int main(int argc, char * argv[]){
    //VARIABLES PARA EL CALCULO DEL TIEMPO
    struct timespec cgt1,cgt2;
    double ncgt;

    //VARIABLES PARA LOS CALCULOS
    double R[40000];
    int ii; double X1=0, X2=0;

    //INICIALIZACION DEL STRUCT
    for(ii = 0; ii<5000; ii++){
        s.a[ii] = ii;
        s.b[ii] = ii+5;
    }

    //CALCULO DE TIEMPO DE EJECUCION...
    clock_gettime(CLOCK_REALTIME,&cgt1);
    for(ii = 0; ii<40000; ii++){
        X1 = 0; X2 = 0;
        for(int i=0; i<5000; i++) X1 += 2*s.a[i]+ii;
        for(int i=0; i<5000; i++) X2 += 3*s.b[i]-ii;

        if(X1 < X2) R[ii]=X1; else R[ii] = X2;
    }
    clock_gettime(CLOCK_REALTIME,&cgt2);

    ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+(double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));

    //MOSTRANDO POR PANTALLA RESULTADOS (5 PRIMEROS Y 5 ÚLTIMOS)
    printf(">> MOSTRANDO RESULTADOS <<\n --> PRIMEROS 5...\n");
    for(ii = 0; ii<5; ii++){
        printf("\t \t R[%d] = %f\n",ii, R[ii]);
    }
    printf(" --> ULTIMOS 5... \n");
    for(ii = 4; ii>=0; ii--){
        printf("\t \t R[%d] = %f\n",39999-ii, R[39999-ii]);
    }

    //MOSTRANDO POR PANTALLA TIEMPO DE EJECUCION
    printf("\n>> TIEMPO DE EJECUCION: %11.9f\n", ncgt);

    return EXIT_SUCCESS;
}
