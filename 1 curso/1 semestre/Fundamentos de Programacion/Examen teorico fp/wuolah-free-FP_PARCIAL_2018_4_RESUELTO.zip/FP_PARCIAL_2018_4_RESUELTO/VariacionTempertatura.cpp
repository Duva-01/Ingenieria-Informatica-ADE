#include <iostream>

using namespace std;

int main()
{  const int TEMPERATURA_MINIMA = -100,
             TEMPERATURA_MAXIMA = 100;
   int contador_temp = 0;
   double temperatura;
   double variacion_minima = 10000;
   double variacion_maxima = 0;
   double diferencia = 0;
   double anterior = 0;

   cout << "Introduzca la secuencia de temperaturas: " ;
   cin >> temperatura ;

   if ( temperatura > TEMPERATURA_MINIMA && temperatura < TEMPERATURA_MAXIMA ){
      while( temperatura > TEMPERATURA_MINIMA && temperatura < TEMPERATURA_MAXIMA){
         diferencia = temperatura - anterior;

         if (diferencia < variacion_minima){
            variacion_minima = diferencia;
         }

         if (diferencia > variacion_maxima){
            variacion_maxima = diferencia;
         }

         contador_temp++ ;
         anterior = temperatura;
         cin >> temperatura;
      }

      cout << "Fin de secuencia: " << contador_temp << " temperaturas procesadas." << endl;

      if(contador_temp > 1){
         cout << "Variaci�n m�xima: " << variacion_maxima << endl;
         cout << "Variaci�n minima: " << variacion_minima << endl;
      }
   }else{
      cout << "Temperatura fuera de rango. No hay datos." ;
  }

    return 0;
}
