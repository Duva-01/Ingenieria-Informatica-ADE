// TDA-Imagen.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include "Imagen.h"
#include <iostream>

using namespace std;

int main()
{
    
    
    UmbralizarGrises("images/llave.pgm", "umbralizar.pgm",100, 250);
    ZoomImagen("images/cameraman.pgm", "zoom.pgm", 50, 100, 250, 250);
    AumentoContraste("images/cameraman.pgm", "contraste.pgm", 50, 150);
    Morphing("images/vacas.pgm", "images/cameraman.pgm", "animacion");
    
    std::cout << "Hello World!\n";
}
