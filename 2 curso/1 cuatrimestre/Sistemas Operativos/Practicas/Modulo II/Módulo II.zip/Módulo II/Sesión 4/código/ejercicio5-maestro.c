#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main(int argc, char* argv[]){
    int fd[2], primo;
    pid_t esclavo_1, esclavo_2;
    char mid_c[20], mid1_c[20];

    // Procesamiento de los argumentos
    if (argc != 3){
        printf("Sintaxis de ejecución: ejercicio5-maestro <a> <b>\n");
        exit(EXIT_FAILURE);
    }

    // [min, max] -> [min, mid] & [mid+1, max]
    int min = atoi(argv[1]), max = atoi(argv[2]);
    int mid = (min + max) / 2;
    sprintf(mid_c, "%d", mid);
    sprintf(mid1_c, "%d", mid+1);

    pipe(fd); // E1 & E2 -> M

    // Ejecución y creación esclavo 1
    if ((esclavo_1 = fork()) == 0){
        close(fd[0]); 
        dup2(fd[1], STDOUT_FILENO);

        // Para que al comenzar a trabajar el esclavo 2 el 1 no haya terminado
        sleep(0.001); 
        execl("./ejercicio5-esclavo", "ejercicio5-esclavo", argv[1], mid_c, NULL);
    }
    // Ejecución y creación esclavo 2
    else if ((esclavo_2 = fork()) == 0){
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);

        execl("./ejercicio5-esclavo", "ejercicio5-esclavo", mid1_c, argv[2], NULL);
    }
    // Ejecución maestro
    else{
        close(fd[1]);

        while (read(fd[0], &primo, sizeof(int)) != 0)
            printf("%d\n", primo);
    }

    return EXIT_SUCCESS;
}