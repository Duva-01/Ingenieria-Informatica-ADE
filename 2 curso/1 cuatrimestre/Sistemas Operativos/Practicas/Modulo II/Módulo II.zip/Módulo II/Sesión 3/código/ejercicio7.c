#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char* argv[]){
    bool background = false; 
    char bg[] = "bg";
    char* argumentos[argc];
    int contador = 0, nargs = argc;

    if (argc == 1){
        printf("Sintaxis de ejecución: ./ejercicio7 <programa> <arg1> <arg2> ...\n");
        exit(1);
    }

    // Procesamiento de los argumentos
    for (int i = 1; i < argc; ++i){
        if (strcmp(bg, argv[i]) == 0){
            background = true;
            nargs -= 1;
        }
        else{
            argumentos[contador] = (char*)malloc(sizeof(argv[i]) * sizeof(char));
            strcpy(argumentos[contador], argv[i]);
            contador += 1;
        }
    }
    argumentos[nargs-1] = NULL;

    if (background){
        // Creamos un proceso hijo que ejecute el programa
        pid_t childpid = fork();
        if (childpid == 0)
            if (execvp(argumentos[0], argumentos) == -1){
                printf("Error en la ejecución del programa.\n");
                exit(EXIT_FAILURE);
            }
    }
    else{
        if (execvp(argumentos[0], argumentos) == -1){
            printf("Error en la ejecución del programa.\n");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < nargs-1; ++i)
        free(argumentos[i]);

    return EXIT_SUCCESS;
}