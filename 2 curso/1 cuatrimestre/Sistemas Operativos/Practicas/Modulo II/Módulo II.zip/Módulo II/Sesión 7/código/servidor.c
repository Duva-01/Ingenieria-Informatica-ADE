/**
 * @file servidor.c
 * @author Grupo 1: Isabel María Moreno Cuadrado, Inmaculada García, Ángel Olmedo, 
 * Juan Fernandez de Cañete, José Daniel Barranquero y Federico Cabrera.
 * @date January 2021
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>

void mimanejador(int senal)
{
    int estado;

    wait(&estado);
}

int main(int argc, char* argv[]){
    char nombre_fifoE[1024], nombre_fifoS[1024], nombre_fifoProxy[1024];
    int fde, fds, fdb;
    int  leido;
    pid_t pid_proxy, pid_cliente;

    signal(SIGCHLD, mimanejador);

    setbuf(stdout, NULL);
    if (argc != 2){
        printf("Sintaxis de ejecución: servidor <fifo_name>\n");
        exit(EXIT_FAILURE);
    }

    sprintf(nombre_fifoE, "%se", argv[1]);
    sprintf(nombre_fifoS, "%ss", argv[1]);

    // Creación de los FIFO Clientes <-> Servidor
    umask(0);
    mkfifo(nombre_fifoE, 0666);
    mkfifo(nombre_fifoS, 0666);

    // Apertura de los FIFO Clientes <-> Servidor
    if ((fde = open(nombre_fifoE, O_RDWR)) == -1){
        printf("Error en la apertura del FIFO de entrada\n");
        exit(EXIT_FAILURE);
    }
    if ((fds = open(nombre_fifoS, O_RDWR)) == -1){
        printf("Error en la apertura del FIFO de salida\n");
        exit(EXIT_FAILURE);
    }

    // Creación del archivo de bloqueo utilizado por los proxys
    if((fdb = open("archivo_bloqueo", O_CREAT, 0666)) < 0){
        printf("\nError al crear el archivo de bloqueo\n");
        exit(EXIT_FAILURE);
    }

    while( (leido = read(fde, &pid_cliente, sizeof(int))) != 0 ){
        printf("Recibida petición del cliente %d. Creando proxy...\n", pid_cliente);
        pid_proxy = fork();

        // Ejecución del proxy
        if (pid_proxy == 0){
            pid_t pidp = getpid();
            int fdp;
            sprintf(nombre_fifoProxy, "fifo.%d", pidp);

            // Creación y apertura del FIFO Proxy <-> Clientes
            mkfifo(nombre_fifoProxy, 0666);
            fdp = open(nombre_fifoProxy, O_RDWR);   // ¿Porque con O_RDONLY se queda colgado?

            // Enviamos por el FIFO Servidor -> Clientes el PID del proxy
            printf("Proxy creado. Enviando proxy %d al cliente %d.\n", pidp, pid_cliente);
            write(fds, &pidp, sizeof(int));

            // Duplicamos el descriptor de archivo del FIFO Proxy en la entrada estándar y ejecutamos
            dup2(fdp, STDIN_FILENO);
            execl("./proxy", "proxy", NULL);
        }
    }

    // Verificamos que no quedan procesos zombie
    // while(wait(NULL) != -1);

    unlink("archivo_bloqueo");
    unlink(nombre_fifoE);
    unlink(nombre_fifoS);

    exit(EXIT_SUCCESS);
}
